#!/usr/bin/env bash
########################################################
### tool to do nslookup by FQDN and IP
###
if [ $# -ne 2 ]; then
   echo ""
   echo "Usage: $0 IP FQDN"
   echo "Example: $0 10.11.165.17 fm17.mpe.vce.lab.com"
   echo ""
   exit 1
fi
ip=$1
fqdn=$2
me=$(hostname)
good=1
echo ""
#
### do nslookup by IP
by_ip=$(nslookup $ip)
if [ "${by_ip/"name = $fqdn"}" = "$by_ip" ]; then
   # no
   ip_resolves="$ip does not resolve"
   to_fqdn=$fqdn
   #echo $by_ip
   good=0
else
   # yes
   ip_resolves="$ip does resolve"
   to_fqdn=$(echo $by_ip | cut -d ' ' -f 8)
fi
res_by_ip="$ip_resolves to $to_fqdn"
#
### do nslookup by FQDN
by_fqdn=$(nslookup $fqdn)
if [ "${by_fqdn/"Address: $ip"}" = "$by_fqdn" ]; then
   # no
   fqdn_resolves="$fqdn does not resolve"
   to_ip=$ip
   #echo $by_fqdn
   good=0
else
   # yes
   fqdn_resolves="$fqdn does resolve"
   to_ip=$(echo $by_fqdn | cut -d ' ' -f 8)
fi
res_by_fqdn="$fqdn_resolves to $to_ip"
#
if [ $good -eq 1 ]; then 
    echo "GOOD on $me     $ip = $fqdn"
else
    echo "BAD on $me    $res_by_ip    $res_by_fqdn"
    #echo $res_by_ip
    #echo $res_by_fqdn
fi
echo ""
