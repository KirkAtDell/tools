#!/usr/bin/env bash
######################################################################
### Look for VMAX discovery records in /root/collectionmanager/CollectionManager
start='/root/collectionmanager/vmax_discovery_start'
stop='/root/collectionmanager/vmax_discovery_stop'
file='/root/collectionmanager/vmax_discoveries3'
grep "CollectionManager - Executing Data Collection with ContextID ARRAY_CONFIG.*10.3.51.85" /root/collectionmanager/CollectionManager > $start
grep "CollectionManager - Collection ARRAY_CONFIG.*10.3.51.85.*has completed" /root/collectionmanager/CollectionManager > $stop
cat $start $stop | sort > $file
echo "   your file is $file"
