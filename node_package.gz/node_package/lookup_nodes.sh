#!/usr/bin/env bash
#############################################################
### Script to execute a nslookup on peer testbed nodes 
### identified in a /etc/hosts file.
###
if [ $# -ne 1 ]; then
    echo ""
    echo "      Usage: $0 TESTBED_HOSTS_FILE"
    echo "    Example: $0 soak_hosts"
    echo ""
    exit 1
fi
# hardcode username and password
username='root'
password='V1rtu@1c3!'
# get command line arguments
hosts_file=$1
# roll through the list for FQDNs and issue them the command argument
while read line
do
    if ! [[ $line == "#"* ]]; then
        #echo "LINE $line"
        # get the essential items, the IP and FQDN
        ip=$(echo $line | cut -d' ' -f 1)
        fqdn=$(echo $line | cut -d' ' -f 2)
        #echo "  IP [$ip] FQDN [$fqdn]"
        ./check_fqdn.sh $ip $fqdn
    fi
done < $hosts_file

