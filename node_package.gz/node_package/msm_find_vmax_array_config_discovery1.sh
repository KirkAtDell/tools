#!/usr/bin/env bash
######################################################################
### Look for VMAX ARRAY_CONFIG discovery records in /root/collectionmanager/CollectionManager
file='/root/collectionmanager/vmax_array_config_discoveries1'
grep "CollectionManager - .*Collection .*ARRAY_CONFIG" /root/collectionmanager/CollectionManager > $file
echo "   your file is $file"
