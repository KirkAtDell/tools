#!/usr/bin/env bash
######################################################################
### Look for Vblock discovery records in /tmp/fmagent/FMAgent
file='/tmp/fmagent/vblock_discoveries'
grep 'scheduler.VblocksDiscoveryService - Performance:All vblocks discovered discoverAll all' /tmp/fmagent/FMAgent > $file
echo "   your file is $file"
