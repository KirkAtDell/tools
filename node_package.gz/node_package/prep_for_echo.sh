#!/usr/bin/env bash
###############################################################
### prepare an sLib for use of ECHO, needs target ECHO IP
if [ $# -ne 1 ]; then
   echo ""
   echo "   Usage: $0 ECHO_IP"
   echo "   Example: $0 10.1.174.239"
   echo ""
   exit -1
fi
echo_ip=$1
curl -k https://$echo_ip/installuse > install_use && chmod +x install_use; ./install_use $echo_ip
