#!/usr/bin/env bash
################################################################################
# Look for stoped services that are important to vision
# cat /tmp/*metrics | grep stopped | grep -v ','
cat /tmp/*metrics | grep stopped | grep -v ','
