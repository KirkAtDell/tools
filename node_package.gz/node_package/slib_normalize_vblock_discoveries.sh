#!/usr/bin/env bash
######################################################################
### process /tmp/fmagent/discoveries into simplier lines
infile='/tmp/fmagent/vblock_discoveries'
host=`hostname`
file="/root/${host}_vblock_discovery.csv"
stats="/root/${host}_vblock_discovery_stats"
echo "### VMAX Discoveries on System Node $host" > $file
started='false'
ended='false'
min=10000000; max=0; ave=0; samples=0; total_time=0
echo "Sample,Discovery (minutes)" > $file
while read l; do
   echo ""; echo $l
   cycle_time=$(echo "$l" | cut -d ' ' -f14 | tr -d 'all\(' | tr -d '\)')
   echo "cycle_time $cycle_time"
   cycle_minutes=$(echo "scale=1;$cycle_time/60000" | bc)
   #echo "....discovery took $cycle_time => $cycle_minutes minutes"
   echo "Vblock discovery took $cycle_minutes minutes"
   (( ++samples ))
   echo "$samples,$cycle_minutes" >> $file
   total_time=$(echo "$total_time + $cycle_minutes" | bc)
   if (( $(echo "$cycle_minutes > $max" | bc -l) )); then
      max=$cycle_minutes
   fi
   if (( $(echo "$min > $cycle_minutes" | bc -l) )); then
      min=$cycle_minutes
   fi
done <$infile
ave=$(echo "scale=1;$total_time/$samples" | bc)
echo "MIN = $min   MAX = $max   AVE = $ave" > $stats
echo "MIN = $min   MAX = $max   AVE = $ave"
