#!/usr/bin/env bash
################################################################################
### query cassandra for the sLib count
/opt/cassandra/bin/cqlsh -u msm_user -p am2ron@p -e  "select count(*) from systeminfo.nodeconfig"
