#!/usr/bin/env bash
###################################################################################
### Script to do nslookup of hosts listed in the testbed_hosts file, by FQDN
###
###
if [ $# -ne 1 ]; then
   echo ""
   echo "  Usage: $0 HOSTS_FILE"
   echo "  Example: $0 3x3x2_hosts"
   echo ""
   exit 1
fi
these_hosts=$1
my_fqdn=$(hostname)
############ node agnostic stuff #####################
### ping the hosts by IP and FQDN
# process our these_hosts file
while read line
do
    if ! [[ $line == "#"* ]]; then
        # get the essential items, the IP and FQDN
        ip=$(echo $line | cut -d' ' -f 1)
        fqdn=$(echo $line | cut -d' ' -f 2)
        # nslookup the fqdn and see if we have an IP match
        by_fqdn=$(nslookup $fqdn)
        #echo "$by_fqdn"
        if [[ $by_fqdn == *"Name:"* ]]; then
           #echo "nslookup of $fqdn works"
           if [[ $by_fqdn == *''* ]]; then
              echo "PASS: $fqdn resolves to $ip"
           else
              echo "FAIL: nslookup of $fqdn fails ============"
              echo "$by_fqdn"
              echo ""
           fi
        else
           echo "FAIL: nslookup of $fqdn fails ============"
           echo "$by_fqdn"
           echo ""
        fi
    fi
done < $these_hosts

