#!/usr/bin/env bash
######################################################################
### Look for VMAX discovery records in /tmp/fmagent/FMAgentPerformance
file='/tmp/fmagent/vmax_discoveries4'
 grep 'percentage = 100.00%' /tmp/fmagent/FMAgentPerformance | grep -v start > $file
echo "   your file is $file"
