#!/usr/bin/env bash
##########################################################################
### this runs the script that rebuilds the /etc/motd
/root/node_package/rebuild_motd.sh testbed_hosts 2>&1
