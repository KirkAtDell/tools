#!/usr/bin/env bash
############################################################
### Script to set up passwordless login to a remote system
### Usage:   ./fixme.sh ACCOUNT <IP of remote system>
### Example: ./fixme.sh root 10.11.165.309
###          ./fixme.sh admin 10.11.32.512
### Before you first run this on your local system, set up your rsa key
ACCOUNT=$1
MACHINE=$2
cat ~/.ssh/id_rsa.pub | ssh $ACCOUNT@$MACHINE 'cat >> .ssh/authorized_keys'

