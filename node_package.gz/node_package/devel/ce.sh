#!/usr/bin/env bash 
HOSTNAME="${COLLECTD_HOSTNAME:-localhost}"
INTERVAL="${COLLECTD_INTERVAL:-60}"

#echo "HOSTNAME is $HOSTNAME and INTERVAL is $INTERVAL"
while sleep "$INTERVAL"; do
  echo "PUTVAL \"$HOSTNAME/ce/gauge-magic_level\" interval=$INTERVAL N:$(date +%N)"
done
