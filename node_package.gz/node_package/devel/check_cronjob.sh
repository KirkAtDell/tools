#!/usr/bin/env bash
#####################################################
### install our cronjob, only once
###
crontable=$(crontab -l)
if echo $crontable | grep -q "Cron to rebuild our motd"
  then echo "rebuilding motd is already scheduled"
  else crontab -l > nowcron; cat nowcron our_cronjob > newcron; crontab newcron; crontab -l
fi
