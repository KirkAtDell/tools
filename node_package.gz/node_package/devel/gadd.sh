#!/usr/bin/env bash
###################################################
### script to use git add on directory with files
FILES=$1/*.cfg
for f in $FILES
do
  echo "converting $1/$f to git"
  dos2unix $1/$f
done
