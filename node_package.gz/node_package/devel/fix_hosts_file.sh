#!/usr/bin/env bash
###################################################################################
### Script to fix the format of the testbed_hosts file
###
###
fqdn=$(hostname)
############ node agnostic stuff #####################
### add testbed_hosts to /etc/hosts file
rm -f new_hosts
touch new_hosts
head -n 3 /etc/hosts > new_hosts
echo "" >> new_hosts
while read line
do
    if ! [[ $line == "###"* ]]; then
        essential=$(echo $line | cut -d' ' -f -2)
        echo $essential >> new_hosts
    else
        #echo $line >> new_hosts
    fi
done < "testbed_hosts"
#

