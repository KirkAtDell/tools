#!/usr/bin/python

# Invoke as: ./restapi-find.py --obj object_to_search_for --msm MSM_FQDN < --user CAS_user> < --pwd CAS_pwd> < --debug True>
# Example: ./restapi-find.py -o switch -m kirk44.mpe.lab.vce.com -u admin -p D@ngerous1 -d True
# Built for Python 2.7

import argparse, sys
import json
import requests
import socket

host = ''
obj = ''
user = ''
pwd = ''
debug = ''

def get_cookie():
	
    if debug == 'True':
    	print "\n<<<<<<<<< DIAGNOSTICS ON >>>>>>>>>>"
    	
    # Setup MSM config, TODO: get from command line

    # Build up base URLS
    base_url = 'https://' + host + ':443'
    tickets_url = base_url + '/cas/v1/tickets'
    cvm_auth_url = base_url + '/cvm/auth'

    # Ticket Granting Ticket
    tgt = requests.request('POST', url=tickets_url, data={'username': user, 'password': pwd}, verify=False)
    if debug == 'True':
        print "\tTGT:        ",tgt
        print "\tTGT HEADERS:",tgt.headers
    st_url = tgt.headers['Location']
    if debug == 'True':
        print "\tST_URL:     ",st_url

    # Service Ticket
    st = requests.request('POST', url=st_url, data='service=' + cvm_auth_url, verify=False)
    if debug == 'True':
        print "\tST:         ",st
        print "\tST TEXT:    ",st.text

    # Get Cookie Jar to chain to data requests
    cj = requests.request('POST', url=cvm_auth_url + '?ticket=' + st.text, verify=False, allow_redirects=False)
    if debug == 'True':
        print "\tCOOKIE-JAR: ",cj
        print "\tCOOKIE-JAR TEXT: ",cj.text
        print "\tCOOKIE-JAR COOKIES: ",cj.cookies

    if debug == 'True':
    	print "\n\n"
    	
    if cj.cookies == '':
    	print "ERROR get_cookie(): the session cookie is blank, cannot continue"
    	exit(1)
    
    return cj.cookies
    

def test_auth_requests(get_cookie):
    """
    Make a request to MSM with an authentication cookie injected
    """
    vblocks_url = 'https://' + host + '/cvm/mvmgmt/queries?q=find ' + obj

    data = requests.request('GET', url=vblocks_url, verify=False, cookies=get_cookie)
    assert data.status_code == requests.codes.ok
    print "MY OUTPUT: "
    parsed = json.loads(data.text)
    print json.dumps(parsed, indent=4, sort_keys=True)
    

if __name__ == '__main__':

    parser = argparse.ArgumentParser(description='This utility issues a find query to the MSM REST API, for some object like a switch or vm.')
    parser.add_argument('-m', '--msm',
        dest='host',
        required=True,
        help='the FQDN of a MSM, no default and required')
    parser.add_argument('-o', '--obj',
        dest='obj',
        help='some object to find (default: switch)',
        default='switch')
    parser.add_argument('-u', '--user',
        dest='user',
        help='CAS user (default: admin)',
        default='admin')
    parser.add_argument('-p', '--pass',
        dest='pwd',
        help='CAS pwd (default: D@ngerous1)',
        default='D@ngerous1')
    parser.add_argument('-d', '--debug',
        dest='debug',
        help='Debug flag (default: False)',
        default='False')
    args = parser.parse_args()
    print args
    
    if args.debug == 'True':
        print 'MSM: ' + args.host
        print 'OBJ: ' + args.obj
        print 'USERNAME: ' + args.user
        print 'PASSWORD: ' + args.pwd
        print 'DEBUG: ' + args.debug
  
    host = args.host
    obj = args.obj
    user = args.user
    pwd = args.pwd
    debug = args.debug

    mycookie = get_cookie()
    test_auth_requests(mycookie)


