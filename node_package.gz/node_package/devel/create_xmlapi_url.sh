#!/usr/bin/env bash
##########################################################################
### Builds URLs, one for the REST client post (postman or other)
### and API queries for the resolutions available in rollup.
###
### This version is intended to be run on your target MSM, the one
### you use the simulator on. It alleviates some concerns that our
### timestamps are aligned with MSM's time.
###
### For now: start time = 'now' - offset
###          end time   = 'now' + offset
### The simulator offset is independent of API query offset (search)
###
if [ $# -ne 3 ]; then
   echo ""
   echo "   Usage: $0 SLIB_FQDN TYPE KPIKEY UID"
   echo "   Example: $0 fm44.v3fx1.vtg.vce.com csIpVt SSI163400HLSSI1634081D%2F%23MSM%23VCESystemCompute%2Fsys%2Fchassis-1%2Fblade-4"
   echo ""
   exit 1
fi
export -f urlencode
export -f urldecode
#
# /cvm/mvmgmt/kpi/kpisdata?endtime=1577836800000&kpikeys=fiTxErrDelta&host=fm42.v3fx1.vtg.vce.com&starttime=1420070400000&uid=SSI163400HLSSI1634081D/%23MSM%23VCESystemCompute/sys/chassis-1/slot-1/host/port-5
#
# https://fm43.v3fx1.vtg.vce.com/cvm/mvmgmt/kpi/kpisdata?endtime=1577836800000&kpikeys=fiTxErrDelta&host=fm42.v3fx1.vtg.vce.com&starttime=1420070400000&uid=SSI163400HLSSI1634081D/%23MSM%23VCESystemCompute/sys/chassis-1/slot-1/host/port-5
#
# specify offsets used for API query and simulation, in hours
search_hours=10000
search_days=365
simulate_hours=2
# get our FQDN ... we are the target MSM used in simulation and API query
msm=$(hostname)
# get the sLib FQDN ... quick and dirty technique, but assumes this MSM was used for capture (bad)
#slib=$(ls -1 /opt/vce/multivbmgmt/capture/ > /tmp/temp; grep XML /tmp/temp | cut -d '_' -f 4)
slib=$1
# specificy the kpikey (Ex: fiRxTot, fiRxTotPack, fiRxErrDelta, fiRxThroughput,fiTxTot, fiTxTotPack, fiTxErrDelta, fiTxThroughput)
kpikeys=portSpeed
kpikeys=fiRxErrDelta
kpikeys=$2
# calculate offsets in milliseconds for API query and simulation
#search_offset=$(echo "$search_hours*60*60*1000" | bc)
search_offset=$(echo "$search_days*24*60*60*1000" | bc)

simoffset=$(echo "$simulate_hours*60*60*1000" | bc)
# specify real UID and fake UID, the simulator doesn't care and neither does the API query, pick one for uid variable
uid1=SSI163400HLSSI1634081D%2F%23MSM%23VCESystemCompute%2Fsys%2Fchassis-2%2Fslot-1%2Fhost%2Fport-1
uid2=SSI163400HLSSI1634081D%2F%23MSM%23VCESystemCompute%2Fsys%2Fchassis-1%2Fslot-1%2Fhost%2Fport-5
uid=$3
# create the endtimes for API query and simulator
# ...currently end times are 'now' plus the offset ... this gives a larger window for debugging the use of simulator and this tool
# ...normally the end times would simply be 'now'
now=$(date +%s%N | cut -b1-13)
today=$(date)
search_starttime=$(echo "$now - $search_offset" | bc)
search_endtime=$(echo "$now + $search_offset" | bc)
sim_starttime=$(echo "$now - $simoffset" | bc)
sim_endtime=$(echo "$now + $simoffset" | bc)

delta=$(echo "$search_endtime - $search_starttime" | bc)
#echo "delta = $delta"
#echo "search_hours = $search_hours  offset = $search_offset"

# override start and end times for debugging
sim_starttime=1421014134000
sim_endtime=1423692534000
# calculate timespan and generate URL
timespan=$(echo \($sim_endtime - $sim_starttime\)/\(60*60*1000\) | bc)
sim_delta=$(echo $timespan/2 | bc)
postman=$(echo http://localhost:8080/kpi/generateKpiData?host=$slib\&uid=$uid\&kpikey=$kpikeys\&startTime=$sim_starttime\&endTime=$sim_endtime)
echo ""
echo "POSTMAN  $postman span is $today +/- $sim_delta hours"

# override start and end times for debugging
#search_starttime=1421014134000
#search_endtime=1423692534000
#search_starttime=1420070400000
#search_endtime=1577836800000
# calculate timespan and generate URLs
timespan=$(echo \($search_endtime - $search_starttime\)/\(24*60*60*1000\) | bc)
search_delta=$(echo $timespan/2 | bc)
url=$(echo https://$msm/cvm/mvmgmt/kpi/kpisdata?endtime=$search_endtime\&kpikeys=$kpikeys\&host=$slib\&starttime=$search_starttime\&uid=$uid) 
echo ""
echo "URL      $url span is $today +/- $search_delta days"
resolution=MINUTE
url=$(echo https://$msm/cvm/mvmgmt/kpi/kpisdata?resolution=$resolution\&endtime=$search_endtime\&kpikeys=$kpikeys\&host=$slib\&starttime=$search_starttime\&uid=$uid) 
echo ""
echo "$resolution $url span is $today +/- $search_delta days"
resolution=HOURLY
url=$(echo https://$msm/cvm/mvmgmt/kpi/kpisdata?resolution=$resolution\&endtime=$search_endtime\&kpikeys=$kpikeys\&host=$slib\&starttime=$search_starttime\&uid=$uid) 
echo ""
echo "$resolution   $url span is $today +/- $search_delta days"
resolution=DAILY
url=$(echo https://$msm/cvm/mvmgmt/kpi/kpisdata?resolution=$resolution\&endtime=$search_endtime\&kpikeys=$kpikeys\&host=$slib\&starttime=$search_starttime\&uid=$uid) 
echo ""
echo "$resolution    $url span is $today +/- $search_delta days"
resolution=WEEKLY
url=$(echo https://$msm/cvm/mvmgmt/kpi/kpisdata?resolution=$resolution\&endtime=$search_endtime\&kpikeys=$kpikeys\&host=$slib\&starttime=$search_starttime\&uid=$uid) 
echo ""
echo "$resolution   $url span is $today +/- $search_delta days"
resolution=MONTHLY
url=$(echo https://$msm/cvm/mvmgmt/kpi/kpisdata?resolution=$resolution\&endtime=$search_endtime\&kpikeys=$kpikeys\&host=$slib\&starttime=$search_starttime\&uid=$uid) 
echo ""
echo "$resolution  $url span is $today +/- $search_delta days"


######################################################
### I got this from stackoverflow
###
rawurlencode() {
  local string="${1}"
  local strlen=${#string}
  local encoded=""
  local pos c o

  for (( pos=0 ; pos<strlen ; pos++ )); do
     c=${string:$pos:1}
     case "$c" in
        [-_.~a-zA-Z0-9] ) o="${c}" ;;
        * )               printf -v o '%%%02x' "'$c"
     esac
     encoded+="${o}"
  done
  #echo "${encoded}"    # You can either set a return variable (FASTER) 
  #REPLY="${encoded}"   #+or echo the result (EASIER)... or both... :p
  return ${encoded}
}
