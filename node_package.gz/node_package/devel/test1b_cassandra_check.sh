#!/usr/bin/env bash
##################################################################################
echo "This version does not abort the calling script when an exit is encountered"
###
echo "define cassandra"
source /opt/vce/multivbmgmt/install/cassandra_check.sh --source-only
echo "check cassandra"
result=$(check_cassandra)
code=$?
#echo "checked cassandra, result = $result"
if [ $code -ne 0 ]; then
   echo "exit code = $code"
   echo $result
else
   echo "exit code = $code"
fi

