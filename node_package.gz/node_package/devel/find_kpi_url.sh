#!/usr/bin/env bash
##########################################################################
### Builds URLs, one for the REST client post (postman or other)
### and API queries for the resolutions available in rollup.
###
### This version is intended to be run on your target MSM, the one
### you use the simulator on. It alleviates some concerns that our
### timestamps are aligned with MSM's time.
###
### For now: start time = 'now' - offset
###          end time   = 'now' + offset
### The simulator offset is independent of API query offset (search)
###
if [ $# -ne 4 ]; then
   echo ""
   echo "   Usage: $0 SLIB_FQDN ELEMENTTYPE KPIKEY ENCODED_UID"
   echo "   Example: $0 qatest210.mpe.lab.vce.com disk saVolAlSp root%2Femc%3ASymm_StorageVolume.CreationClassName%3D%22Symm_StorageVolume%22%2CDeviceID%3D%22FF8D3%22%2CSystemCreationClassName%3D%22Symm_StorageSystem%22%2CSystemName%3D%22SYMMETRIX-%2B-000196701111%22"
   echo "   Example: $0 vision174-240.vb700swqa.vcemo.lab disk saDskTlIOPs root%2Femc%3ASymm_DiskDrive.CreationClassName%3D%22Symm_DiskDrive%22%2CDeviceID%3D%2238F%22%2CSystemCreationClassName%3D%22Symm_StorageSystem%22%2CSystemName%3D%22SYMMETRIX-%2B-000196701333%22"
   echo ""
   exit 1
fi
export -f urlencode
#
msm='fm43.v3fx1.vtg.vce.com'
slib='vision174-240.vb700swqa.vcemo.lab'
elementtype='disk'
kpikeys='saVolAlSp'
starttime='1429036221815'
endtime='1492108221815'
uid='root%2Femc%3ASymm_StorageVolume.CreationClassName%3D%22Symm_StorageVolume%22%2CDeviceID%3D%22FF8D3%22%2CSystemCreationClassName%3D%22Symm_StorageSystem%22%2CSystemName%3D%22SYMMETRIX-%2B-000196701111%22'
#
# saVolAlSp 
# https://fm43.v3fx1.vtg.vce.com/cvm/mvmgmt/kpi/kpisdata?host=qatest210.mpe.lab.vce.com&starttime=1429036221815&endtime=1492108221815&elementtype=disk&kpikeys=saVolAlSp&uid=root%2Femc%3ASymm_StorageVolume.CreationClassName%3D%22Symm_StorageVolume%22%2CDeviceID%3D%22FF8D3%22%2CSystemCreationClassName%3D%22Symm_StorageSystem%22%2CSystemName%3D%22SYMMETRIX-%2B-000196701111%22
#
# saDskTlIOPs
# https://fm43.v3fx1.vtg.vce.com/cvm/mvmgmt/kpi/kpisdata?starttime=1429036221815&endtime=1492108221815&elementtype=disk&kpikeys=saDskTlIOPs&host=vision174-240.vb700swqa.vcemo.lab&uid=root%2Femc%3ASymm_DiskDrive.CreationClassName%3D%22Symm_DiskDrive%22%2CDeviceID%3D%2238F%22%2CSystemCreationClassName%3D%22Symm_StorageSystem%22%2CSystemName%3D%22SYMMETRIX-%2B-000196701333%22
#
# get our FQDN ... we are the target MSM used in simulation and API query
msm=$(hostname)
# get the sLib FQDN ... quick and dirty technique, but assumes this MSM was used for capture (bad)
slib=$1
# get the element type
elementtype=$2
# specify the kpikey (Ex: fiRxTot, fiRxTotPack, fiRxErrDelta, fiRxThroughput,fiTxTot, fiTxTotPack, fiTxErrDelta, fiTxThroughput)
kpikeys=$3
# get the encoded uid
uid=$4
# create the endtimes for API query and simulator
# ...currently end times are 'now' plus the offset ... this gives a larger window for debugging the use of simulator and this tool
# ...normally the end times would simply be 'now'
# specify offsets used, in hours
search_days=10
# calculate offsets in milliseconds for API query and simulation
search_offset=$(echo "$search_days*24*60*60*1000" | bc)
now=$(date +%s%N | cut -b1-13)
today=$(date)
# calculate the start and end times by subtrating and adding the offset
search_starttime=$(echo "$now - $search_offset" | bc)
search_endtime=$(echo "$now + $search_offset" | bc)
# calculate the timespan of the search window
delta=$(echo "$search_endtime - $search_starttime" | bc)
#echo "delta = $delta"

# calculate timespan and generate URL
timespan=$(echo \($search_endtime - $search_starttime\)/\(24*60*60*1000\) | bc)
search_delta=$(echo $timespan/2 | bc)
url=$(echo https://$msm/cvm/mvmgmt/kpi/kpisdata?host=$slib\&starttime=$search_starttime\&endtime=$search_endtime\&elementtype=$elementtype\&kpikeys=$kpikeys\&uid=$uid) 
echo ""
echo " $url"
echo "     span is $today +/- $search_delta days"
echo ""

