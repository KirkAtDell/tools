#!/usr/bin/python
"""
Experiment with stuff
"""

import subprocess

print dir(subprocess)

print subprocess
