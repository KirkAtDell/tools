#!/usr/bin/python

# Invoke as: ./restapi-kpi-k1.py --msm MSM_FQDN < --user CAS_user> < --pwd CAS_pwd>  < --debug True>
#                                < --slib SLIB_FQDN>
#                                < --kpi kpi_name> 
#                                < --id uniqueId>
#                                < --stime start_time> < --etime end_time>
# Example: ./restapi-kpi-k1.py -m kirk44.mpe.lab.vce.com -u admin -p D@ngerous1 -d True\
#                              -s kirk45.mpe.lab.vce.com \
#                              -k consumedPower \
#                              -i SSI16230AFDSSI162506QT/#MSM#VCESystemCompute/sys/chassis-2/blade-5 \
#                              -s 07172017_0330 -e 07172017_1600
# Built for Python 2.7

import argparse, sys
import json
import requests
import socket
import urllib
import datetime
import time
import math

host = ''
slib = ''
user = ''
pwd = ''
debug = ''
kpi = ''
uid = ''
stime = ''
etime = ''

epoch = datetime.datetime.utcfromtimestamp(0)

def unix_time_millis(dt):
    return (dt - epoch).total_seconds() * 1000.0

def get_cookie():
	
    if debug == 'True':
    	print "\n<<<<<<<<< DIAGNOSTICS ON >>>>>>>>>>"
    	
    # Setup MSM config, TODO: get from command line

    # Build up base URLS
    base_url = 'https://' + host + ':443'
    tickets_url = base_url + '/cas/v1/tickets'
    cvm_auth_url = base_url + '/cvm/auth'

    # Ticket Granting Ticket
    tgt = requests.request('POST', url=tickets_url, data={'username': user, 'password': pwd}, verify=False)
    if debug == 'True':
        print "\tTGT:        ",tgt
        print "\tTGT HEADERS:",tgt.headers
    st_url = tgt.headers['Location']
    if debug == 'True':
        print "\tST_URL:     ",st_url

    # Service Ticket
    st = requests.request('POST', url=st_url, data='service=' + cvm_auth_url, verify=False)
    if debug == 'True':
        print "\tST:         ",st
        print "\tST TEXT:    ",st.text

    # Get Cookie Jar to chain to data requests
    cj = requests.request('POST', url=cvm_auth_url + '?ticket=' + st.text, verify=False, allow_redirects=False)
    if debug == 'True':
        print "\tCOOKIE-JAR: ",cj
        print "\tCOOKIE-JAR TEXT: ",cj.text
        print "\tCOOKIE-JAR COOKIES: ",cj.cookies

    if debug == 'True':
    	print "\n\n"
    	
    if cj.cookies == '':
    	print "ERROR get_cookie(): the session cookie is blank, cannot continue"
    	exit(1)
    
    return cj.cookies
    

def test_auth_requests(get_cookie):
    """
    Make a request to MSM with an authentication cookie injected
    """
    vblocks_url = 'https://' + host + '/cvm/mvmgmt/kpi/kpisdata?host=' + slib + '&kpikeys=' + kpi + '&uid=' + uid + '&starttime=' + str(btime) + '&endtime=' + str(etime)
    print "URL: " + vblocks_url
    data = requests.request('GET', url=vblocks_url, verify=False, cookies=get_cookie)
    if debug == 'True':
        print "data: " + str(data)
    assert data.status_code == requests.codes.ok
    print "MY OUTPUT: "
    parsed = json.loads(data.text)
    print json.dumps(parsed, indent=4, sort_keys=True)
    

if __name__ == '__main__':

    parser = argparse.ArgumentParser(description='This utility issues a query to the MSM REST API, for KPI data for some piece of the system. A time span is given for which KPI data is collected.')
    parser.add_argument('-m', '--msm',
        dest='host',
        required=True,
        help='the FQDN of a MSM, no default and required')
    parser.add_argument('-s', '--slib',
        dest='slib',
        required=True,
        help='the FQDN of a sLib, no default and required')
    parser.add_argument('-u', '--user',
        dest='user',
        help='CAS user (default: admin)',
        default='admin')
    parser.add_argument('-p', '--pass',
        dest='pwd',
        help='CAS pwd (default: D@ngerous1)',
        default='D@ngerous1')
    parser.add_argument('-d', '--debug',
        dest='debug',
        help='Debug flag (default: False)',
        default='False')
    parser.add_argument('-k', '--kpi',
        dest='kpi',
        help='some KPI to find (consumedPower: csCnsPw)',
        default='csCnsPw')
    parser.add_argument('-i', '--id',
        dest='id',
        help='UID for KPI value search',
        default='SSI16230AFDSSI162506QT/#MSM#VCESystemCompute/sys/chassis-2/blade-5')
    parser.add_argument('-b', '--btime',
        dest='btime',
        required=True,
        help='begin time for KPI value search: 7/17/2017 15:00:00 UTC')
    parser.add_argument('-e', '--etime',
        dest='etime',
        required=True,
        help='end time for KPI value search (defaults to now)')
    args = parser.parse_args()
    print args
    
    if args.debug == 'True':
        print 'MSM:      ' + args.host
        print 'sLIB:     ' + args.slib
        print 'USERNAME: ' + args.user
        print 'PASSWORD: ' + args.pwd
        print 'DEBUG:    ' + args.debug
        print 'KPI:      ' + args.kpi
        print 'UID:      ' + args.id
        print 'BTIME:    ' + args.btime
        print 'ETIME:    ' + args.etime
      
    host  = args.host
    slib  = args.slib
    user  = args.user
    pwd   = args.pwd
    debug = args.debug
    kpi   = args.kpi
    uid   = urllib.quote_plus(args.id)
    btime = int(unix_time_millis(datetime.datetime.strptime(args.btime, "%m/%d/%Y %H:%M:%S %Z")))
    etime = int(unix_time_millis(datetime.datetime.strptime(args.etime, "%m/%d/%Y %H:%M:%S %Z")))

    if args.debug == 'True':
        print 'UID:      ' + uid
        print  btime
        print  etime
    
    mycookie = get_cookie()
    test_auth_requests(mycookie)


