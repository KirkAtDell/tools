#!/usr/bin/env bash
###################################################################################
### Script to add aliases
###
###

############ slib/MSM specific stuff #################
msm_has_multivbmgmt=$(ls -1 /opt/vce | grep -i multivbmgmt)
if [ "$msm_has_multivbmgmt" = "" ]; then
  # do sLib only stuff
  #
  ### add some useful qa aliases
  cat aliases_slib_tue aliases_slib_johnS aliases_slib_kirk | sort -u | grep -v '###' | grep -v '\*\*' > new_common
  cat aliases_custom_banner new_common >> new_aliases
  #
  ### add any specific post process commands
  command='/opt/vce/fm/bin/startEulaAcceptance'
  #
else
  # do msm only stuff
  #
  ### add some useful qa aliases
  cat aliases_msm_johnS aliases_msm_tue aliases_msm_kirk > new_aliases
  #
  ### add any specific post process commands
  command=''
  #
fi
#
############ node agnostic stuff #####################
### add aliases to ~/.bashrc file
mv ~/.bashrc old_bashrc
#cat bashrc_head new_aliases urlencoder bashrc_tail > bashrc
cat bashrc_head new_aliases bashrc_tail > bashrc
chmod 755 bashrc
mv bashrc ~/.bashrc
