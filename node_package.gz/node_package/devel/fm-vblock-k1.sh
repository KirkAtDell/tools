#!/bin/bash

echo

# wait for 5 minutes for initial discovery

SCRIPT_NAME=`basename $0`
SCRIPT_VERSION="version 1.0"

#for SNMP
HOST=$1
COMMUNITY_STRING=public
SNMP_VERSION=-v2c

FName="vblocks"
MSG=msg

# for REST 
REST_USERNAME=admin
REST_PASSWORD=7j%40m4Qd%2B1L
REST_SERVER=https://$HOST:8443
TICKETS=https://$HOST:8443/cas/v1/tickets
VBLOCKS="${REST_SERVER}/fm/$FName"
SHIROCAS=${REST_SERVER}/fm/auth

# file


TGT=`curl -s -S -k -D - -d "username=${REST_USERNAME}&password=${REST_PASSWORD}" ${TICKETS} 2>&1 | grep Location | grep TGT | awk -F/ '{printf $NF}'`

############################################
# Resource VBLOCKS discovery....
############################################

TGT=`echo $TGT | tr -d '\r'`
#get Service Ticket
ST=`curl -s -S -k -d "service=${SHIROCAS}" -q ${TICKETS}/${TGT}`

#Get the resource starting from VBLOCKS


output=$(curl -c cookies.txt -s -k -L ${SHIROCAS}?ticket=$ST)

# CMD_OUT=$(curl -b cookies.txt -s -k -LO ${VBLOCKS})
$(curl -b cookies.txt -s -k -LO ${VBLOCKS})
if [ $? -eq 0 ]; then
 echo "REST resource VBLOCKS: ${VBLOCKS}: SUCCESS"
    echo -e "${VBLOCKS} : \t Success ">>$MSG
    FNAME_W_DATE=${FName}_"$(date +%Y-%d-%m_%H:%M)"_${HOST}
    mv $FName $FNAME_W_DATE.xml
    xmllint --format -o $FNAME_W_DATE.txt $FNAME_W_DATE.xml 
else
    echo "REST resource VBLOCKS: ${VBLOCKS}: FAILED"
    echo
    exit 1
fi
head -n 10 $FNAME_W_DATE.txt
