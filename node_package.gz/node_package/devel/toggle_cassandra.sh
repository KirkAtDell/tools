#!/usr/bin/env bash
############################################################################
### This script is used to test the cassandra_check.sh script's behavior in
### several /etc/init.d scripts. It toggles Cassandra down and then up, 
### pausing for a user-specified number of seconds.
###
### To run a test on tomcat, multivbmgmt or vision-credential-manager:
###   1) stop the relevant /etc/init.d service
###   2) in a 2nd shell window, run this toggle script
###   3) when you see the message 'delaying 60 seconds' 
###   4) quickly start the service
###   5) confirm that the start is delayed until you see toggle's message
###      saying starting cassandra
###   6) also confirm a running cassandra process is shown in the toggle
###      window
###
# get the seconds argument
if [ $# -ne 1 ]; then
    echo ""
    echo "      Usage: $0 <seconds>"
    echo "    Example: $0 30"
    echo ""
    exit 1
fi
seconds=$1
#
# Flush data to disk and stop the CQL listener
echo "draining cassandra"
/opt/cassandra/bin/nodetool drain
echo "cassandra drained"
#
# Stop Cassandra
echo "stopping cassandra"
pid=$(cass=$(ps auwwx | grep cassandra); echo $cass | cut -d ' ' -f2); echo "killing $pid"; kill $pid
echo "cassandra stopped"
#
echo "delaying $seconds seconds"
# delay
sleep $seconds
#
# start Cassandra
echo "starting cassandra"
/opt/cassandra/install/start_cassandra.sh
echo "cassandra started"
ps auwwx | grep cassandra
