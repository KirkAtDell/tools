#!/usr/bin/python

import urllib
import datetime
import time
import math

epoch = datetime.datetime.utcfromtimestamp(0)

def unix_time_millis(dt):
    return (dt - epoch).total_seconds() * 1000.0
    
uid   = 'SSI16230AFDSSI162506QT/#MSM#VCESystemCompute/sys/chassis-2/blade-5'
print "UID: " + uid
print "ENCODED UID: " + urllib.quote_plus(uid)

print "START TIME ============="
stime = '7/17/2017 03:30:05 CDT'
print "SDT: " + stime
sdt = datetime.datetime.strptime(stime, "%m/%d/%Y %H:%M:%S %Z")
print sdt
start = unix_time_millis(sdt)
print int(start)

print "END TIME ==============="
nowepoch = datetime.datetime.now()
now = time.mktime(nowepoch.timetuple())*1e3 + nowepoch.microsecond/1e3
print int(now)