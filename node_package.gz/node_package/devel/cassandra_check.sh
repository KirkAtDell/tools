#!/bin/bash

function check_cassandra()
{
    MVMGMT_HOME=/opt/vce/multivbmgmt/mods/com.vce.vision~CollectionManagerWeb~0/
    jext=/usr/java/latest/lib/ext

    counter=1

    HOST=`hostname -i`
    CQL_PASS=`java -Djava.ext.dirs=$MVMGMT_HOME/lib:$jext com.vce.securitylibrary.tools.GetInfoApp`

    if [ $? -ne 0 ] ; then
        echo "Failed to get Cassandra context"
        exit -10
    fi

    echo "Checking if Cassandra is Up and Normal on node $HOST"

    while [ $counter -ne 60 ] ;
    do
        echo "    Checking Cassandra [ $counter / 60 ]"
        /usr/bin/expect <<DONE
            log_user 0
            spawn {*}"/opt/cassandra/bin/cqlsh -u msm_user -e \"select * from system.schema_keyspaces\""

            expect "*?assword:*"
            send "$CQL_PASS\r"

            expect eof

            lassign [wait] pid spawnid os_error_flag value
            log_user 1
            exit \$value
DONE
        result=$?

        if [ $result -eq 0 ] ; then
            echo "Cassandra is Up and Normal on node $HOST"
            exit 0
        fi

        sleep 10
        let counter++
    done

    echo "Cassandra is not running Up and Normal"
    exit -1
}

