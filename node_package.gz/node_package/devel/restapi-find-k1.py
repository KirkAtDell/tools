#!/usr/bin/python

# Invoke as: ./restapi-find.py --obj <object to search for> --msm <MSM_FQDN> --username <CAS username> --password <CAS password>
# Example: ./restapi-find.py --obj switch --msm kirk44.mpe.lab.vce.com --username admin --password D@ngerous1
# Built for Python 2.7

import getopt, sys, subprocess
import json
import requests
import socket

host = ''
obj = ''
username = ''
password = ''
debug = 'False'

def get_cookie():
	
    if debug == 'True':
    	print "\n<<<<<<<<< DIAGNOSTICS ON >>>>>>>>>>"
    	
    # Setup MSM config, TODO: get from command line

    # Build up base URLS
    base_url = 'https://' + host + ':443'
    tickets_url = base_url + '/cas/v1/tickets'
    cvm_auth_url = base_url + '/cvm/auth'

    # Ticket Granting Ticket
    tgt = requests.request('POST', url=tickets_url, data={'username': username, 'password': password}, verify=False)
    if debug == 'True':
        print "\tTGT:        ",tgt
        print "\tTGT HEADERS:",tgt.headers
    st_url = tgt.headers['Location']
    if debug == 'True':
        print "\tST_URL:     ",st_url

    # Service Ticket
    st = requests.request('POST', url=st_url, data='service=' + cvm_auth_url, verify=False)
    if debug == 'True':
        print "\tST:         ",st
        print "\tST TEXT:    ",st.text

    # Get Cookie Jar to chain to data requests
    cj = requests.request('POST', url=cvm_auth_url + '?ticket=' + st.text, verify=False, allow_redirects=False)
    if debug == 'True':
        print "\tCOOKIE-JAR: ",cj
        print "\tCOOKIE-JAR TEXT: ",cj.text
        print "\tCOOKIE-JAR COOKIES: ",cj.cookies

    if debug == 'True':
    	print "\n\n"
    	
    if cj.cookies == '':
    	print "ERROR get_cookie(): the session cookie is blank, cannot continue"
    	exit(1)
    
    return cj.cookies
    

def test_auth_requests(get_cookie):
    """
    Make a request to MSM with an authentication cookie injected
    """
    vblocks_url = 'https://' + host + '/cvm/mvmgmt/queries?q=find ' + obj

    data = requests.request('GET', url=vblocks_url, verify=False, cookies=get_cookie)
    assert data.status_code == requests.codes.ok
    print "MY OUTPUT: "
    parsed = json.loads(data.text)
    print json.dumps(parsed, indent=4, sort_keys=True)
    

if __name__ == '__main__':
    host = ''
    obj = ''
    username = ''
    password = ''
    try:
        opts, args = getopt.getopt(sys.argv[1:], "ho:v", ["help", "msm=", "obj=", "username=", "password=", "debug="])
    except getopt.GetoptError, err:
        # print help information and exit:
        print "\n\t", sys.argv[0], " --msm <FQDN> --obj <object to find> --username <username> --password <password> --debug <True>"
        print "\n\t\t", str(err), "\n" # will print something like "option -a not recognized"
        sys.exit(2)
    output = None
    verbose = False
    for o, a in opts:
        if o == "-v":
            verbose = True
        elif o in ("-h", "--help"):
            print """\n\tScript to GET JSON data from MSM's REST API for some object find
            \t--msm       : FQDN of some MSM
            \t--obj       : some object to find
            \t--username  : MSM CAS username
            \t--password  : MSM CAS password
            \t--debug     : Option sets debug flag True
            \n"""
            sys.exit()
        elif o in ("--msm"):
            host = a
        elif o in ("--obj"):
            obj = a
        elif o in ("--username"):
            username = a
        elif o in ("--password"):
            password = a
        elif o in ("--debug"):
            debug = a
        else:
            assert False, "unhandled option"
    # ...
    
    response = call("nslookup host")
    print response
    
    print "DEBUG:    ", debug
    print "HOST:     ", host
    print "OBJ:      ", obj
    print "USER:     ", username
    print "PASSWORD: ", password

    mycookie = get_cookie()
    test_auth_requests(mycookie)


