#!/usr/bin/env bash
############################################################
### Script to set up passwordless root login to a linux box
### Before you first run this on a new box, ssh-keygen -t rsa
MACHINE=$1
cat ~/.ssh/id_rsa.pub | ssh root@$MACHINE 'cat >> .ssh/authorized_keys'
