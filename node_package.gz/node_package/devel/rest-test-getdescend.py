#!/usr/bin/python

import getopt, sys, re
import json
import pytest
import requests
#import vcr
import socket
import certifi
import urllib3
http = urllib3.PoolManager(cert_reqs='CERT_REQUIRED',ca_certs=certifi.where())
#http.request('GET', 'https://google.com')
#http.request('GET', 'https://expired.badssl.com')

#count of objects returned from vcesystem descendants call - 30min
#*/30 * * * * /root/rest-test-getdescend.py >> /tmp/countofobjects


#host = 'kirk44.mpe.lab.vce.com'
#host = 'kirk250.mpe.lab.vce.com'
#host = 'kirk57.mpe.lab.vce.com'
host = 'kirk58.mpe.lab.vce.com'
#host = socket.gethostname()
obj = 'switch'

def get_cookie():
    # Setup MSM config, TODO: get from command line
    username = 'admin'
    password = 'D@ngerous1'

    # Build up base URLS
    base_url = 'https://' + host + ':443'
    tickets_url = base_url + '/cas/v1/tickets'
    cvm_auth_url = base_url + '/cvm/auth'

    # Ticket Granting Ticket
    tgt = requests.request('POST', url=tickets_url, data={'username': username, 'password': password}, verify=False)
    print "TGT: ",tgt
    st_url = tgt.headers['Location']
    print "ST_URL: ",st_url

    # Service Ticket
    st = requests.request('POST', url=st_url, data='service=' + cvm_auth_url, verify=False)
    print "ST: ",st

    # Get Cookie Jar to chain to data requests
    cj = requests.request('POST', url=cvm_auth_url + '?ticket=' + st.text, verify=False, allow_redirects=False)
    print "COOKIE-JAR: ",cj

    return cj.cookies


from requests.packages.urllib3.exceptions import InsecurePlatformWarning, InsecureRequestWarning,SNIMissingWarning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
requests.packages.urllib3.disable_warnings(InsecurePlatformWarning)
requests.packages.urllib3.disable_warnings(SNIMissingWarning)


def test_auth_requests(get_cookie):
    """
    Make a request to MSM with an authentication cookie injected
    """
    #vblocks_url = 'https://' + host + '/cvm/mvmgmt/queries?q=find descendants of vcesystem'
    vblocks_url = 'https://' + host + '/cvm/mvmgmt/queries?q=find ' + obj

    data = requests.request('GET', url=vblocks_url, verify=False, cookies=get_cookie)
    assert data.status_code == requests.codes.ok
    print "MY OUTPUT: "
    parsed = json.loads(data.text)
    print json.dumps(parsed, indent=4, sort_keys=True)
    #print data.json()['summary']['hits'],
    #print data.json()['summary']['queryRespTime']
    #assert data.json()['summary']['hits'] > 0


if __name__ == '__main__':
    mycookie = get_cookie()
    test_auth_requests(mycookie)


