#!/usr/bin/env bash
######################################################################
### Create a single FMAgent.log file, in /tmp, from the current log
### and all of the archived logs. The archives are of the form
### FMAgent.log.2016-08-05.1.gz. Gunzips to FMAgent.log.2016-08-05.1
### 
# copy the gz files to /tmp and uncompress them
cd /tmp
rm -rf fmagent
mkdir fmagent
cd /opt/vce/fm/logs
cp FMAgent* /tmp/fmagent
cd /tmp/fmagent
gunzip FMAgent.log.*.gz
command='cat '
FILES=FMAgent.log.*
for f in $FILES
do
   echo "...appending $f to FMAgent"
   cat $f >> FMAgent
done
cat FMAgent.log >> FMAgent

