#!/usr/bin/python
"""
Experiment with stuff
"""

import argparse

parser = argparse.ArgumentParser(description='Process some command line options.')
parser.add_argument('-m', '--msm',
    dest='host',
    required=True,
    help='the FQDN of a MSM, no default')
parser.add_argument('-o', '--obj',
    dest='obj',
    help='some object to find (default: switch)',
    default='switch')
parser.add_argument('-u', '--user',
    dest='username',
    help='CAS username (default: admin)',
    default='admin')
parser.add_argument('-p', '--pass',
    dest='password',
    help='CAS password (default: D@ngerous1)',
    default='D@ngerous1')
parser.add_argument('-d', '--debug',
    dest='debug',
    help='Debug flag (default: False)',
    default='False')
args = parser.parse_args()
print args

if args.debug == 'True':
    print 'MSM: ' + args.host
    print 'OBJ: ' + args.obj
    print 'USERNAME: ' + args.username
    print 'PASSWORD: ' + args.password
    print 'DEBUG: ' + args.debug
