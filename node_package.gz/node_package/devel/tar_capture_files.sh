#
# Copyright (c) 2015 VCE Company, LLC. All rights reserved.
# VCE Confidential/Proprietary Information
#

#/bin/bash

currentDir=`pwd`
FQDN=`hostname -f`

MVB_HOME="/opt/vce/multivbmgmt"
MVB_CAPTURE="$MVB_HOME/capture"

# check if the json file is ready 
for entry in "$MVB_CAPTURE"/*.json
do
	echo "--------------------------------"
	echo  ${entry}
	endline=`tail -1 ${entry}|grep ']'`
	if [ "${endline}" = "" ]; then
		echo "${entry} is not ready yet"
		exit 1;
	fi
done

cd ${MVB_HOME}

tar -cvzf ${FQDN}_capture.tar.gz capture

echo "${MVB_HOME}/${FQDN}_capture.tar.gz is created."

cd ${currentDir}
