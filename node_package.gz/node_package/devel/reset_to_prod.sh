#!/bin/sh
#
# Copyright (c) 2015 VCE Company, LLC. All rights reserved.
# VCE Confidential/Proprietary Information
#


SCRIPT_NAME=`basename $0`
FQDN=`hostname -f`

dateStr=$(date +"%Y_%m_%d_%H_%M")

MVB_HOME="/opt/vce/multivbmgmt"

MULTIVB_SCHEMA="$MVB_HOME/install/post_install_schema.sh"

MVB_QA_HOME="$MVB_HOME/qa"

MVB_CAPTURE_HOME="$MVB_HOME/capture"

if [ ! -f ${MULTIVB_SCHEMA} ]; then
    echo "${MULTIVB} not found!" >&2
    exit 1
fi

. ${MULTIVB_SCHEMA}

if [ $? -ne 0 ]; then
    echo "Failed to load ${MULTIVB_SCHEMA}!" >&2
    exit 1
fi

# set qa work home
[ -d "${MVB_QA_HOME}" ] || mkdir ${MVB_QA_HOME}




export MVB_PROFLE=replay

#------------------------------------------------------------
# Function: parse_arguments to parse input arguments
#------------------------------------------------------------
parse_arguments(){
   if [ $# -eq 0 ]
   then
      return 0
   fi

   # Parse command line options.
   while getopts "h" OPT
   do
      case "$OPT" in
         h)
            displayInfo
            exit 0
            ;;
         *?)
            # getopts issues an error message
            echo "Invalid input!"
            displayInfo
            ;;			
      esac
   done

   # Remove the switches we parsed above.
   shift `expr $OPTIND - 1`
}


#------------------------------------------------------------
# Function: usage to print the command usage
#------------------------------------------------------------
displayInfo(){
   echo "This script will reset the multivbmgmt service back to production mode,"
   echo "assuming the vision config files are not changed, and Slib VMs are up and running."
   echo "  "     
}
#------------------------------------------------------------
# Function: set runtime profile as replay
#------------------------------------------------------------
resetProfile(){
	# TDO backup vision dir
	# TDO copy vision dir from capture to conf
	#
	sed -i -e "s/^#MVB_PROFILE=.*/#MVB_PROFILE=${MVB_PROFILE}/g"\
           -e "s/^MVB_PROFILE=.*/#MVB_PROFILE=${MVB_PROFILE}/g" ${MVB_HOME}/bin/setupenv.sh

	# disable amqp
	sed -i -e "s/^amqp.enabled=.*/amqp.enabled=true/g" ${MVB_HOME}/conf/cvm-config.properties		   
}


#------------------------------------------------------------
# Function: parse_arguments to parse input arguments
#------------------------------------------------------------
resetSchedule(){
    
	service multivbmgmt stop

	service tomcat stop
		
	/bin/cp ${MVB_HOME}/db/systeminfo.scheduleconfig.csv ${MVB_QA_HOME}/systeminfo.scheduleconfig.csv
	
	populateDefaults localhost ${MVB_QA_HOME}
	
	service tomcat start
	
	# wait 30 seconds to allow tomcat service be ready
	echo "wait 30 seconds before starting multivbmgmt service..."
	sleep 30
	
	service multivbmgmt start
	
}


#------------------------------------------------------------
# Main routine
#------------------------------------------------------------
parse_arguments "$@"

resetProfile

resetSchedule