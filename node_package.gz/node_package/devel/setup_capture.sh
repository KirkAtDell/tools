#!/bin/sh
#
# Copyright (c) 2015 VCE Company, LLC. All rights reserved.
# VCE Confidential/Proprietary Information
#


SCRIPT_NAME=`basename $0`
FQDN=`hostname -f`

dateStr=$(date +"%Y_%m_%d_%H_%M")

MVB_HOME="/opt/vce/multivbmgmt"

MULTIVB_SCHEMA="$MVB_HOME/install/post_install_schema.sh"

MVB_CAPTURE="$MVB_HOME/capture"

MVB_QA_HOME="$MVB_HOME/qa"

if [ ! -f ${MULTIVB_SCHEMA} ]; then
    echo "${MULTIVB} not found!" >&2
    exit 1
fi

. ${MULTIVB_SCHEMA}

if [ $? -ne 0 ]; then
    echo "Failed to load ${MULTIVB_SCHEMA}!" >&2
    exit 1
fi

# set qa work home
[ -d "${MVB_QA_HOME}" ] || mkdir ${MVB_QA_HOME}

# make capture dir if not exist
[ -d "${MVB_CAPTURE}" ] || mkdir ${MVB_CAPTURE}
chown -R multivbmgmt:vce ${MVB_CAPTURE}


MVB_PROFILE=capture

#------------------------------------------------------------
# Function: setup capture
#------------------------------------------------------------
setupCapture(){
	# set profile to capture
	sed -i -e "s/^#MVB_PROFILE=.*/MVB_PROFILE=${MVB_PROFILE}/g" \
	-e "s/^MVB_PROFILE=.*/MVB_PROFILE=${MVB_PROFILE}/g" ${MVB_HOME}/bin/setupenv.sh
	
	# disable amqp
	sed -i -e "s/^amqp.enabled=.*/amqp.enabled=false/g" ${MVB_HOME}/conf/cvm-config.properties
	
	# remove the old config files and cp vision config files
	if [ -d "${MVB_CAPTURE}/vision" ]; then
		\rm -rf "${MVB_CAPTURE}/vision"
	fi
	
	cp -rf ${MVB_HOME}/conf/vision ${MVB_CAPTURE}
	
}



#------------------------------------------------------------
# Function: parse_arguments to parse input arguments
#------------------------------------------------------------
parse_arguments(){
   if [ $# -eq 0 ]
   then
      return 0
   fi

   # Parse command line options.
   while getopts "hsc" OPT
   do
      case "$OPT" in
         s)
            SILENT=TRUE
            ;;
         c)
            CONTINUOUS=TRUE
            ;;
         h)
            usage
            exit 0
            ;;
         *?)
            # getopts issues an error message
            echo "Invalid input!"
            usage
            exit 1
            ;;
      esac
   done

   # Remove the switches we parsed above.
   shift `expr $OPTIND - 1`
}


#------------------------------------------------------------
# Function: usage to print the command usage
#------------------------------------------------------------
usage(){
   echo ""
   echo "Usage:"
   echo "    $SCRIPT_NAME -s -h -c"
   echo "    where"
   echo "        -s: run this script in silent mode"
   echo "        -c: run the capture in continuous mode"
   echo "        -h: show this message"
   echo "  "     
}

#------------------------------------------------------------
# function: confirmCapture
#	confirm Capture 
#------------------------------------------------------------
confirmCapture(){
	invalid=0
	echo " "
	echo "WARNING!! Please don't run this script on production environment."
	echo "   This script will set both schedule and multivbmgmt to capture mode."
	echo "   it will also restart Tomcat and multivbmgmt services."
	echo " "
	echo "Do you really want to do it?"
	select choice in "Yes" "No"
	do
	   case $choice in
		  Yes ) user_choice="Yes"
				return 0
				;;
		   No ) user_choice="No"
				exit 1
				break
				;;
			* ) echo "Invalid option! Please re-enter"
				if [ $invalid -ge 3 ]
				then
				   echo "exceeded the maximum attempt. Exiting..."
				   exit 1
				fi
				((invalid++))
				;;
	   esac
	done
}
#------------------------------------------------------------
# Function: setupScheduleAndRestart
#      load the capture schedule to C*, and restart services
#------------------------------------------------------------
setupScheduleAndRestart(){
    
	service multivbmgmt stop

	service tomcat stop
	
	if [ "${CONTINUOUS}" != "TRUE" ]; then	
		/bin/cp ${MVB_HOME}/db/systeminfo.scheduleconfig.csv.capture ${MVB_QA_HOME}/systeminfo.scheduleconfig.csv
		
		populateDefaults localhost ${MVB_QA_HOME}
	fi
	service tomcat start
	
	# wait 30 seconds to allow tomcat service be ready
	echo "wait 30 seconds before starting multivbmgmt service..."
	sleep 30
	
	service multivbmgmt start
}


#------------------------------------------------------------
# Main routine
#------------------------------------------------------------
parse_arguments "$@"

if [ "$SILENT" != "TRUE" ]; then
	confirmCapture
fi

setupCapture

setupScheduleAndRestart