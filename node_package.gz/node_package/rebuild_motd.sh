#!/usr/bin/env bash
##############################################################
### rebuild our motd
###
############ node agnostic stuff #####################
### we need to find our who we are and what we're about, from the these_hosts file
# who are we?
fqdn=$(/bin/hostname)
# get our line from these_hosts file
# start building the motd ... add a couple of blank lines
mv /etc/motd /tmp/old_motd
$(echo " " > /tmp/motd; echo " " >> /tmp/motd)


############ slib/MSM specific stuff #################
# we need to know whether we're a MSM or a sLib ... MSM has multivbmgmt directory
msm_has_multivbmgmt=$(ls -1 /opt/vce | grep -i multivbmgmt)
if [ "$msm_has_multivbmgmt" = "" ]; then
  # do sLib only stuff
  #
  ### create a sLib motd
  if [ ! -f /opt/vce/fm/conf/vxrack.xml ]; then
  	# get our Vblock serial number
    SerialNumber=$(grep SerialNumber /opt/vce/fm/conf/vblock.xml)
    serialNumber=$(echo $SerialNumber | sed "s/<SerialNumber>//g" | sed "s/<\/SerialNumber>//g")
    # add context (from agnostic section), and serial number to the motd
    new_motd=$(echo "    sLib: $fqdn"; echo " "; echo "        vblock: $serialNumber"; echo " ")
  else
  	# get our vxrack serial number
    SerialNumber=$(grep serialNumber /opt/vce/fm/conf/vxrack.xml)
    serialNumber=$(echo $SerialNumber | sed "s/<serialNumber>//g" | sed "s/<\/serialNumber>//g")
    # add context (from agnostic section), and serial number to the motd
    new_motd=$(echo "    sLib: $fqdn"; echo " "; echo "        vxrack: $serialNumber"; echo " ")
  fi
  #
  # do the getFMinfo thing and get version information
  /opt/vce/fm/bin/getFMagentInfo > /tmp/this_getFMagentInfo
  perl -pi -e 's/^/    /g' /tmp/this_getFMagentInfo 
  version=$(head -n 5 /tmp/this_getFMagentInfo)
  #
else
  # do msm only stuff
  #
  ### create a MSM motd
  # get the list of sLibs we manage
  /opt/vce/multivbmgmt/install/listSlibNodes.sh > /tmp/new_slibs
  perl -pi -e 's/^/        /g' /tmp/new_slibs 
  slibs=$(cat /tmp/new_slibs)
  # add context (from agnostic section), and sLibs to the motd
  new_motd=$(echo "    MSM: $fqdn"; echo "$slibs")
  # do the rpm greppin' thing and get version information
  ver=$(rpm -qa | grep vision-multi-system-management)
  version=$(echo "    $ver")
  #
fi

############ node agnostic stuff #####################
### create motd
# add what we have so far to /tmp/motd
$(echo "$new_motd" >> /tmp/motd)
# add the version information, too
$(echo "$version" >> /tmp/motd)
# and a couple of blank lines
$(echo " " >> /tmp/motd; echo " " >> /tmp/motd)
# now make this our /etc/motd
mv -f /tmp/motd /etc/motd

