#!/usr/bin/env bash
######################################################################
### Create a single CollectionManager file, in /tmp, from the current log
### and all of the archived logs. The archives are of the form
### CollectionManager-08-05.1.gz. Gunzips to CollectionManager-08-05.1
### 
# copy the gz files to /tmp and uncompress them
cd /root
rm -rf collectionmanager
mkdir collectionmanager
cd /opt/vce/multivbmgmt/logs
cp CollectionManager* /root/collectionmanager
cd /root/collectionmanager
gunzip CollectionManager.log.*.gz
command='cat '
FILES=CollectionManager.log.*
for f in $FILES
do
   echo "...appending $f to CollectionManager"
   cat $f >> CollectionManager
done
echo "...appending CollectionManager.log to CollectionManager"
cat CollectionManager.log >> CollectionManager
echo " the log is /root/collectionmanager/CollectionManager"

