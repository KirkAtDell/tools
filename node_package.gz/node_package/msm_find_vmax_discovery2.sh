#!/usr/bin/env bash
######################################################################
### Look for VMAX discovery records in /tmp/collectionmanager/CollectionManager
start='/tmp/collectionmanager/vmax_discovery_start'
stop='/tmp/collectionmanager/vmax_discovery_stop'
file='/tmp/collectionmanager/vmax_discoveries2'
grep "CollectionManager - Executing Data Collection with ContextID ARRAY_CONFIG.*10.3.51.85" /tmp/collectionmanager/CollectionManager > $start
grep "CollectionManager - Collection ARRAY_CONFIG.*10.3.51.85.*has completed" /tmp/collectionmanager/CollectionManager > $stop
cat $start $stop | sort > $file
echo "   your file is $file"
