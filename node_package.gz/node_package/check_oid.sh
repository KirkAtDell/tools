#!/usr/bin/env bash
################################################
### Script that uses snmpwalk to check oids.
###  snmpwalk -c 'public' -v2c 10.11.34.6 1.3.6.1.2.1.2
###
if [ $# -ne 3 ]; then
   echo ""
   echo "  Usage: $0 COMMUNITY_STRING DEVICE_IP oid"
   echo "  Usage: $0 public 10.11.34.6 1.3.6.1.2.1"
   echo ""
   exit 1
fi
community=$1
ip=$2
oid=$3
snmpwalk -c "$community" -v2c $ip $oid
