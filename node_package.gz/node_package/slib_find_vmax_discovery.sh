#!/usr/bin/env bash
######################################################################
### Look for begin/end VMAX discovery records in /tmp/fmagent/FMAgent
file='/tmp/fmagent/vmax_discoveries'
grep 'Start discover' /tmp/fmagent/FMAgent | grep -i -v cisco | grep -i -v ucs | grep -v ARRAY > /tmp/fmagent/starts
grep 'Done discover' /tmp/fmagent/FMAgent | grep -i -v cisco | grep -i -v ucs > /tmp/fmagent/dones
cat /tmp/fmagent/starts /tmp/fmagent/dones | sort > $file
echo "   your file is $file"
