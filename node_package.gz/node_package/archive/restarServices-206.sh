#!/usr/bin/env bash
#
# Copyright (c) 2015 VCE Company, LLC. All rights reserved.
# VCE Confidential/Proprietary Information
#


LOG_NAME="/opt/vce/multivbmgmt/logs/joinMSMCluster.log"
CRED_MGR_CLI="/opt/vce/credential-management/bin/credential-manager-cli"
IP=`echo $(hostname -I)`


function restart_main_services
{
    local rc=0
    echo "Restarting services. Please wait ..."
    for service in tomcat httpd vision-credential-manager; do
        local status=1
        local n=0
        local max_attempts=3
        while [[ $status -ne 0 && $n -lt $max_attempts ]]; do
            if [ "$VERBOSE" = "true" ]; then
                service $service status
                if [ $? -eq 0 ]; then
                    service $service restart
                    status=$?
                else
                    service $service start
                    status=$?
                fi
            else
                service $service status >> "$LOG_NAME" 2>&1
                if [ $? -eq 0 ]; then
                    service $service restart >> "$LOG_NAME" 2>&1
                    status=$?
                else
                    service $service start >> "$LOG_NAME" 2>&1
                    status=$?
                fi
            fi
            (( n = $n + 1 ))
            sleep 15
        done
        (( rc = $rc + $status ))
        if [ $status -ne 0 ]; then
            echo "Failed to restart $service service!"
        fi
        if [ "$service" = "vision-credential-manager" ]; then
            wait_for_credential_manager 18
            status=$?
            (( rc = $rc + $status ))
            if [ $status -ne 0 ]; then
                echo "Timed out after 180 seconds waiting for credential manager to start!"
            fi
        fi
        sleep 30
    done
    echo
    return $rc
}




function restart_app_services(){
echo "Restarting services. Please wait ..."
    for service in multivbmgmt vision-subscription-manager vision-mvb-compliance vision-msm-tech-support vision-web-ui vision-shell; do
        local status=1
        local n=0
        local max_attempts=3
        while [[ $status -ne 0 && $n -lt $max_attempts ]]; do
            service $service restart
            status=$?
            sleep 30
            service $service status
            (( status = $status + $? ))
            (( n = $n + 1 ))
        done
        if [ $status -ne 0 ]; then
            echo "Failed to restart $service service!"
            return 1
        fi
    done

}

restart_main_services
restart_app_services
