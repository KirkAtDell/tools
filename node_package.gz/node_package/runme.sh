#!/usr/bin/env bash
###################################################################################
### Script to add testbed hosts to /etc/hosts, add aliases and create a /etc/motd
###
###
fqdn=$(hostname)
############ node agnostic stuff #####################
### wait until we see Done in firstboot, or up to 20 minutes
#echo "This script will not run unitl the deployment is successful. It will check for success for 20 minutes"
#...commands needed here...TBD

### create /etc/motd
rebuild_motd.sh

############ slib/MSM specific stuff #################
msm_has_multivbmgmt=$(ls -1 /opt/vce | grep -i multivbmgmt)
if [ "$msm_has_multivbmgmt" = "" ]; then
  # do sLib only stuff
  #
  ### add some useful qa aliases
  cat aliases_slib_tue aliases_slib_johnS aliases_slib_kirk | sort -u | grep -v '###' | grep -v '\*\*' > new_common
  cat aliases_custom_banner new_common >> new_aliases
  #
  ### add any specific post process commands
  command='/opt/vce/fm/bin/startEulaAcceptance'
  #
else
  # do msm only stuff
  #
  ### add some useful qa aliases
  cat aliases_msm_johnS aliases_msm_tue aliases_msm_kirk urlencoder > new_aliases
  #
  ### add any specific post process commands
  #command='cp -f /root/node_package/devel/amqpclient.gz /tmp; cd /tmp; tar xvfz amqpclient.gz; cp -R /root'
  command='cp -f /root/node_package/devel/amqpclient.gz ~; tar xvfz amqpclient.gz; rm -f amqpclient.gz'
  #
fi
#
### add aliases to ~/.bashrc file
mv ~/.bashrc old_bashrc
cat bashrc_head new_aliases bashrc_tail > bashrc
chmod 755 bashrc
mv bashrc ~/.bashrc
#
### create a cronjob to rebuild /etc/motd periodically
### install our cronjob, only once
###
crontable=$(crontab -l)
if echo $crontable | grep -q "Cron to rebuild our motd"
  then echo "rebuilding the motd is already scheduled"
  else crontab -l > nowcron; cat nowcron our_cronjob > newcron; crontab newcron; crontab -l
fi
#
### run any post setup commands
$command
#
### advise user to enable the new aliases and set up keygen for rootme.sh
echo "Now run . ~/.bashrc to make the new aliases available to this shell"
echo ""

