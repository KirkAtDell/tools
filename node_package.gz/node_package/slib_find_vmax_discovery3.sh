#!/usr/bin/env bash
######################################################################
### Look for VMAX discovery records in /tmp/fmagent/FMAgentPerformance
file='/tmp/fmagent/vmax_discoveries3'
grep '\[VMAXServices.discover\] accumulatively took' /tmp/fmagent/FMAgentPerformance | grep -E 'took [0-9]{7} ms' > $file
echo "   your file is $file"
