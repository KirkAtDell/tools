#!/usr/bin/env bash
##########################################################
### checking a port for access
### netstat -plntu | grep 5999
if [ $# -ne 1 ]; then
   echo ""
   echo "Usage: $0 PORT"
   echo "Example: $0 5999"
   echo ""
   exit 1
fi
netstat -plntu | grep $1
