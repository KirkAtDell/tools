#!/usr/bin/env bash
###################################################################################
### Script to fix the format of the testbed_hosts file
###
###
if [ $# -ne 1 ]; then
   echo ""
   echo "  Usage: $0 HOSTS_FILE"
   echo "  Example: $0 3x3x2_hosts"
   echo ""
   exit 1
fi
these_hosts=$1
fqdn=$(hostname)
############ node agnostic stuff #####################
### add testbed_hosts to /etc/hosts file
rm -f new_hosts
touch new_hosts
head -n 3 /etc/hosts > new_hosts
echo "" >> new_hosts
while read line
do
    if ! [[ $line == "###"* ]]; then
        if ! [[ $line == *"$fqdn"* ]]; then
            essential=$(echo $line | cut -d' ' -f -2)
            echo $essential >> new_hosts
        fi
    #else
        #echo $line >> new_hosts
    fi
done < $these_hosts
