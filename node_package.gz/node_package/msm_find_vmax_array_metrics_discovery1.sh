#!/usr/bin/env bash
######################################################################
### Look for VMAX ARRAY_METRICS discovery records in /root/collectionmanager/CollectionManager
file='/root/collectionmanager/vmax_array_metrics_discoveries1'
grep "CollectionManager - .*Collection .*ARRAY_METRICS" /root/collectionmanager/CollectionManager > $file
echo "   your file is $file"
