#!/usr/bin/env bash
######################################################################
### Look for VMAX discovery records in /tmp/collectionmanager/CollectionManager
start='/tmp/collectionmanager/vmax_discovery_start'
stop='/tmp/collectionmanager/vmax_discovery_stop'
file='/tmp/collectionmanager/vmax_discoveries'
grep 'collector.CollectionExecutor - Starting collection for context VISION_CONFIG' /tmp/collectionmanager/CollectionManager > $start
grep 'collector.CollectionExecutor - Data collection CONFIG succeeded for ContextID VISION_CONFIG' /tmp/collectionmanager/CollectionManager > $stop
cat $start $stop | sort > $file
echo "   your file is $file"
