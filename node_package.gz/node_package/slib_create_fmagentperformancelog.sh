#!/usr/bin/env bash
######################################################################
### Create a single FMAgentPerformance.log file, in /tmp, from the current log
### and all of the archived logs. The archives are of the form
### FMAgentPerformance.log.2016-08-05.1.gz. Gunzips to FMAgentPerformance.log.2016-08-05.1
### 
# copy the gz files to /tmp and uncompress them
cd /tmp
rm -rf fmagent
mkdir fmagent
cd /opt/vce/fm/logs
cp FMAgentPerformance* /tmp/fmagent
cd /tmp/fmagent
gunzip FMAgentPerformance.log.*.gz
command='cat '
FILES=FMAgentPerformance.log.*
for f in $FILES
do
   echo "...appending $f to FMAgentPerformance"
   cat $f >> FMAgentPerformance
done
echo "...appending FMAgentPerformance.log to FMAgentPerformance"
cat FMAgentPerformance.log >> FMAgentPerformance
echo " the log is /tmp/fmagent/FMAgentPerformance"

