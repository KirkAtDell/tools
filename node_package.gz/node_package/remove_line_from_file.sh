#!/usr/bin/env bash
###########################################################
# Need something to purge line from a file. Move file to
# /tmp, read it and remove a line matching a pattern.
#
if [ $# -ne 2 ]; then
   echo ""
   echo "  Usage: $0 FILE SEARCH_STRING"
   echo "  Example: $0 ~/.ssh/known_hosts 10.11.165.43"
   echo "  Example: $0 ~/.ssh/known_hosts fm43.v3fx1"
   echo ""
   exit 1
fi
# make a timestamp
ts=$(date -u +"%Y%m%d%H%M%S")
filepath=$1
filename=$(echo ${filepath##*/})
#echo "filepath = $filepath"
#echo "filename = $filename"
pattern=$(echo $2 | cut -d '.' -f1)
#echo "pattern = $pattern"
mv $filepath /tmp/$filename.$ts
sed "/$pattern/d" /tmp/$filename.$ts > $filepath
echo " Your original file is at /tmp/$filename.$ts"
