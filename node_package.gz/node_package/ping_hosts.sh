#!/usr/bin/env bash
###################################################################################
### Script to ping hosts listed in the testbed_hosts file, by IP and FQDN
###
###
if [ $# -ne 1 ]; then
   echo ""
   echo "  Usage: $0 HOSTS_FILE"
   echo "  Example: $0 3x3x2_hosts"
   echo ""
   exit 1
fi
these_hosts=$1
my_fqdn=$(hostname)
############ node agnostic stuff #####################
### ping the hosts by IP and FQDN
# process our these_hosts file
while read line
do
    if ! [[ $line == "#"* ]]; then
        # don't ping ourself
        if ! [[ $line == *"$my_fqdn"* ]]; then
            # get the essential items, the IP and FQDN
            ip=$(echo $line | cut -d' ' -f 1)
            fqdn=$(echo $line | cut -d' ' -f 2)
            # ping by IP and FQDN
            by_ip=$(ping -c 1 $ip)
            by_fqdn=$(ping -c 1 $fqdn)
            if [[ $by_ip == *"1 received"* ]]; then
               ip_msg="pinging $ip works"
            else
               ip_msg="pinging $ip fails"
            fi
            if [[ $by_fqdn == *"1 received"* ]]; then
               fqdn_msg="pinging $fqdn works"
            else
               fqdn_msg="pinging $fqdn fails"
            fi
            echo "$ip_msg ... $fqdn_msg"
        fi
    fi
done < $these_hosts

