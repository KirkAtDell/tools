#!/usr/bin/env bash
######################################################################
### Look for VMAX discovery records in /tmp/fmagent/FMAgent
file='/tmp/fmagent/vmax_discoveries2'
grep 'scheduler.FMScheduledThreadPoolExecutor - Task VB740-MAX-975-318-123_discoverAll_VMAX-ARRAY finished with elapsed' /tmp/fmagent/FMAgent > $file
echo "   your file is $file"
