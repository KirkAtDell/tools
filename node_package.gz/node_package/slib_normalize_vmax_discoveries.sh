#!/usr/bin/env bash
######################################################################
### process /tmp/fmagent/discoveries into simplier lines
infile='/tmp/fmagent/vmax_discoveries'
host=`hostname`
file="/root/${host}_vmax_discovery.csv"
echo "### VMAX Discoveries on System Node $host" > $file
started='false'
ended='false'
min=10000000; max=0; ave=0; samples=0; total_time=0
echo "Sample,Discovery (minutes)" > $file
while read l; do
   #echo $l
   d=$(echo $l | cut -d ' ' -f2)
   t=$(echo $l | cut -d ' ' -f3)
   s=$(echo $l | cut -d ' ' -f9)
   then=`date --date="$d $t" +%s`
   #echo "$s $then"
   if [ $s == 'Start' ] && [ $started == 'false' ]; then # cycle started
      dstart=$then  # discovery start
      started='true'
      starting="$l"
      #echo "...discovery cycle started"
   else
      if [ $s == 'Done' ] && [ $started == 'true' ]; then  # cycle ended
         dend=$then # discovery end
         ended='true'
         ending="$l"
         #echo "...discovery cycle ended"
      fi
   fi
   if [ $started == 'true' ] && [ $ended == 'true' ]; then # good cycle, compute and dump
      started='false'
      ended='false'
      cycle_time=`expr $dend - $dstart`
      #echo "....$cycle_time"
      cycle_minutes=$(echo "scale=1;$cycle_time/60" | bc)
      #echo "....time difference is $cycle_time => $cycle_minutes minutes"
      if [[ "$dend" -ge "$dstart" ]]; then
         echo ""; echo "$starting"; echo "$ending"
         echo "VMAX discovery took $cycle_minutes minutes"
         (( ++samples ))
         echo "$samples,$cycle_minutes" >> $file
         total_time=$(echo "$total_time + $cycle_minutes" | bc)
         if (( $(echo "$cycle_minutes > $max" | bc -l) )); then
            max=$cycle_minutes
         fi
         if (( $(echo "$min > $cycle_minutes" | bc -l) )); then
            min=$cycle_minutes
         fi
      fi
   fi
done <$infile
ave=$(echo "scale=1;$total_time/$samples" | bc)
echo "MIN = $min   MAX = $max   AVE = $ave"
