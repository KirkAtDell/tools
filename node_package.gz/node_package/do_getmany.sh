#!/usr/bin/env bash
# Use -gt 1 to consume two arguments per pass in the loop (e.g. each
# argument has a corresponding value to go with it).
# Use -gt 0 to consume one or more arguments per pass in the loop (e.g.
# some arguments don't have a corresponding value to go with it such
# as in the --default example).
# note: if this is set to -gt 0 the /etc/hosts part is not recognized ( may be a bug )
while [[ $# -ge 1 ]]
do
key="$1"

case $key in
    -t|--target)
    target="$2"
    shift # past argument
    ;;
    -c|--community)
    community="$2"
    shift # past argument
    ;;
    -o|--oid)
    oid="$2"
    shift # past argument
    ;;
    -h|--help)
    echo ""
    echo "Usage: $0 -t 10.3.20.108 -c snmp4lab -o 1.3.6.1.4.1.9.9.719.1.15.56"
    echo ""
    exit 1
    ;;
    --default)
    DEFAULT=YES
    ;;
    *)
            # unknown option
    ;;
esac
shift # past argument or value
done
echo target     = "${target}"
echo community  = "${community}"
echo oid        = "${oid}"
echo "target=$target, community=$community, oid=$oid"
### getmany -v2c 10.3.20.108 snmp4lab 1.3.6.1.4.1.9.9.719.1.15.56
getmany -v2c $target $community $oid
# End of file
