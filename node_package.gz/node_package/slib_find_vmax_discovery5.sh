#!/usr/bin/env bash
######################################################################
### Look for VMAX discovery records in /tmp/fmagent/FMAgentPerformance
file='/tmp/fmagent/vmax_discoveries5'
 #grep 'percentage = 100.00%' /tmp/fmagent/FMAgentPerformance | grep -v start > $file
#grep '100.00%' /tmp/fmagent/FMAgentPerformance | grep discoverAll | cut -d ' ' -f21
grep '100.00%' /tmp/fmagent/FMAgentPerformance | grep discoverAll > $file
echo "   your file is $file"
