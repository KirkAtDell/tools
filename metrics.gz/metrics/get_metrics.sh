#!/usr/bin/env bash
####################################################################
### Script to gather metrics concerning the computer's resources
### ./get_metrics.sh

# make a timestamp
ts=$(date -u +"%Y%m%d%H%M%S")
# get list of vision rpms
visionrpms_trunc=$(rpm -qa | sort | grep vision | tr '\n' ' '| cut -c -80)
echo "$ts NEW_ROW $(hostname) $visionrpms_trunc"

# get list of users on system
users=$(who | sed -r -e "s/[\t\ ]+/ /g" | sed ':a;N;$!ba;s/\n/,/g')
echo "$ts USERS $users"

# get list of vision rpms
visionrpms=$(rpm -qa | sort | grep vision | tr '\n' ' ')
echo "$ts VISION-RPMS $visionrpms"

# run top once and stick in temp file
top -n 1 -b > top_shot

# get the header of the temp top file
head -n 5 top_shot | sed -r -e "s/[\t\ ]+/ /g" > top_header

# parse the uptime from top_header
uptime=$(cat top_header | grep load | cut -d ' ' -f 5- | cut -d ' ' -f -3 | sed s/\,$//)
echo "$ts UPTIME $uptime"

# parse the load from the top_header
load=$(cat top_header | grep load | cut -d ' ' -f 12-14)
echo "$ts LOAD $load"

# parse the tasks from the top_header
tasks=$(cat top_header | grep -i tasks | cut -d ' ' -f 2-)
echo "$ts TASKS $tasks"

# parse the memory from the top_header
memory=$(cat top_header | grep -i mem | cut -d ' ' -f 2-)
echo "$ts MEMORY $memory"

# parse the swap from the top_header
swap=$(cat top_header | grep -i swap | cut -d ' ' -f 2-)
echo "$ts SWAP $swap"

# use mpstat to get CPU utilization
cpu=$(mpstat | grep 0 | grep -v Lin | grep -v CPU | cut -d ' ' -f 9-)
echo "$ts CPU $cpu"

# get the number of open files
openfiles=$(/usr/sbin/lsof | wc -l)
echo "$ts LSOF $openfiles"

# get the number of allocated file handles, number of allocated but not used, and the maximum
handles=$(/sbin/sysctl fs.file-nr | cut -d ' ' -f 3- | sed -r -e "s/[\t\ ]+/ /g")
echo "$ts FS.FILE-NR $handles"

# get iostats
iostat=$(/usr/bin/iostat | grep sd | sed -r -e "s/[\t\ ]+/ /g")
echo "$ts IOSTAT $iostat"

# get eht0 received packets
rxpacket=$(/sbin/ifconfig eth0 | grep packets | grep RX | sed -r -e "s/[\t\ ]+/ /g" | sed 's/ /,/g' | sed 's/,RX,//'| sed 's/:/ /g' | sed 's/,/, /g')
echo "$ts ETH0-RX $rxpacket"

# get eht0 transmitted packets
txpacket=$(/sbin/ifconfig eth0 | grep packets | grep TX | sed -r -e "s/[\t\ ]+/ /g" | sed 's/ /,/g' | sed 's/,TX,//'| sed 's/:/ /g' | sed 's/,/, /g')
echo "$ts ETH0-TX $txpacket"

# get count of errors in messages log
messageerrors=$(cat /var/log/messages | grep -i error | wc -l)
echo "$ts MESSAGES-ERROR $messageerrors"

# get count of warnings in messages log
messagewarnings=$(cat /var/log/messages | grep -i warn | wc -l)
echo "$ts MESSAGES-WARN $messagewarnings"

############ node specific stuff #################
node=$(ls -1 /opt/vce | grep -i multivbmgmt)$(ls -1 /opt/vce | grep -i fm)$(ls -1 /opt/vce | grep -i msp)
if [ $node = 'multivbmgmtmsp' ]; then
  node="multivbmgmt"
fi
echo "$ts NODE $node"
case "$node" in
"fm")
  # do sLib only stuff

  # get crond status
  crond=$(/sbin/service crond status | cut -d ' ' -f 6 | sed 's/\.\.\.//')
  if [ "$crond" == "running" ]; then
     echo "$ts CROND $crond"
  else
     echo "$ts CROND stopped"
  fi
  
  # get ntpd status
  ntpd=$(/sbin/service ntpd status | cut -d ' ' -f 6 | sed 's/\.\.\.//')
  if [ "$ntpd" == "running" ]; then
     echo "$ts NTPD $ntpd"
  else
     echo "$ts NTPD stopped"
  fi

  #check vce services, one-by-one
  vce_fm_master=$(/sbin/service vce-fm-master status | cut -d ' ' -f 2- | sed 's/ /_/g' | sed 's/_(pid=[0-9]*_)//')
  if [ "$vce_fm_master" == "is_running" ]; then
     echo "$ts VCE-FM-MASTER running"
  else
     echo "$ts VCE-FM-MASTER stopped"
  fi

  vce_fm_adapter=$(/sbin/service vce-fm-adapter status | cut -d ' ' -f 2- | sed 's/ /_/g' | sed 's/_(pid=[0-9]*_)//')
  if [ "$vce_fm_adapter" == "is_running" ]; then
     echo "$ts VCE-FM-ADAPTER running"
  else
     echo "$ts VCE-FM-ADAPTER stopped"
  fi

  vce_fm_agent=$(/sbin/service vce-fm-agent status | cut -d ' ' -f 2- | sed 's/ /_/g' | sed 's/_(pid=[0-9]*_)//')
  if [ "$vce_fm_agent" == "is_running" ]; then
     echo "$ts VCE-FM-AGENT running"
  else
     echo "$ts VCE-FM-AGENT stopped"
  fi

  vce_fm_net_snmpd=$(/sbin/service vce-fm-net-snmpd status | cut -d ' ' -f 4- | sed 's/ /_/g')
  if [ "$vce_fm_net_snmpd" == "is_running" ]; then
     echo "$ts VCE-FM-NET-SNMPD running"
  else
     echo "$ts VCE-FM-NET-SNMPD stopped"
  fi

  vce_fm_naaagent=$(/sbin/service vce-fm-naaagent status | cut -d ' ' -f 2- | sed 's/ /_/g' | sed 's/_(pid=[0-9]*_)//')
  if [ "$vce_fm_naaagent" == "is_running" ]; then
     echo "$ts VCE-FM-NAAAGENT running"
  else
     echo "$ts VCE-FM-NAAAGENT stopped"
  fi

  #run configuration collector
  ;;
"multivbmgmt")
  # do msm only stuff

  # run edge.py
  edges=$(/root/metrics/edge.py)
  echo "$ts EDGES $edges"

  # run rest-test-getdescend.py
  hits=$(/root/node_package/devel/rest-test-getdescend.py 2>/dev/null)
  echo "$ts OBJECTS $hits"

  # get df  information on VCE data space
  vcedata=$(df | egrep "\/opt\/vce\/data")
  echo "$ts VCE-DATA $vcedata"

  # get count of errors in CollectionManager.log
  collectionerrors=$(cat /opt/vce/multivbmgmt/logs/CollectionManager.log | grep -i error | wc -l)
  echo "$ts COLLECTION-ERROR $collectionerrors"

  # get count of warnings in CollectionManager.log
  collectionwarnings=$(cat /opt/vce/multivbmgmt/logs/CollectionManager.log | grep -i warn | wc -l)
  echo "$ts COLLECTION-WARN $collectionwarnings"

  # get tomcat status
  tomcat=$(/sbin/service tomcat status | cut -d ' ' -f 6 | sed 's/\.//')
  if [ "$tomcat" == "running" ]; then
     echo "$ts TOMCAT $tomcat"
  else
     echo "$ts TOMCAT stopped"
  fi
  
  # get crond status
  crond=$(/sbin/service crond status | cut -d ' ' -f 6 | sed 's/\.\.\.//')
  if [ "$crond" == "running" ]; then
     echo "$ts CROND $crond"
  else
     echo "$ts CROND stopped"
  fi
  
  # get ntpd status
  ntpd=$(/sbin/service ntpd status | cut -d ' ' -f 6 | sed 's/\.\.\.//')
  if [ "$ntpd" == "running" ]; then
     echo "$ts NTPD $ntpd"
  else
     echo "$ts NTPD stopped"
  fi

  # get httpd status
  httpd=$(/sbin/service httpd status | cut -d ' ' -f 6 | sed 's/\.\.\.//')
  if [ "$httpd" == "running" ]; then
     echo "$ts HTTPD $httpd"
  else
     echo "$ts HTTPD stopped"
  fi
  
  # get rsyslog status
  rsyslog=$(/sbin/service rsyslog status | cut -d ' ' -f 6 | sed 's/\.\.\.//')
  if [ "$rsyslog" == "running" ]; then
     echo "$ts RSYSLOG $rsyslog"
  else
     echo "$ts RSYSLOG stopped"
  fi
  
  # get elasticsearch status
  elasticsearch=$(/sbin/service elasticsearch status | cut -d ' ' -f 6 | sed 's/\.\.\.//')
  if [ "$elasticsearch" == "running" ]; then
     echo "$ts ELASTICSEARCH $elasticsearch"
  else
     echo "$ts ELASTICSEARCH stopped"
  fi
  
  # get multivbmgmt status
  multivbmgmt=$(/sbin/service multivbmgmt status  | cut -d ' ' -f 6  | sed 's/\.\.\.//')
  if [ "$multivbmgmt" == "running" ]; then
     echo "$ts MULTIVBMGMT $multivbmgmt"
  else
     echo "$ts MULTIVBMGMT stopped"
  fi
  
  # get vision-shell status
  vision_shell=$(/sbin/service vision\-shell status | cut -d ' ' -f 5)
  if [ "$vision_shell" == "running" ]; then
     echo "$ts VISION-SHELL $vision_shell"
  else
     echo "$ts VISION-SHELL stopped"
  fi
  
  # get vision-credential-manager status
  vision_credential_manager=$(/sbin/service vision\-credential\-manager status | cut -d ' ' -f 6 | sed 's/\.//')
  if [ "$vision_credential_manager" == "running" ]; then
     echo "$ts VISION-CREDENTIAL-MANAGER $vision_credential_manager"
  else
     echo "$ts VISION-CREDENTIAL-MANAGER stopped"
  fi
  
  # get vision-credential-manager-cli status
  vision_credential_manager_cli=$(/opt/vce/credential-management/bin/credential-manager-cli status | cut -d ' ' -f 6 | sed 's/\.//')
  if [ "$vision_credential_manager_cli" == "running" ]; then
     echo "$ts VISION-CREDENTIAL-MANAGER-CLI $vision_credential_manager_cli"
  else
     echo "$ts VISION-CREDENTIAL-MANAGER-CLI stopped"
  fi

  # get vision-mvb-compliance status
  vision_mvb_compliance=$(/sbin/service vision\-mvb\-compliance status | cut -d ' ' -f 6 | sed 's/\.//')
  if [ "$vision_mvb_compliance" == "running" ]; then
     echo "$ts VISION-MVB-COMPLIANCE $vision_mvb_compliance"
  else
     echo "$ts VISION-MVB-COMPLIANCE stopped"
  fi
  
  # get rabbitmq-server status
  rabbitmq_server=$(/sbin/service rabbitmq-server status)
  if [[ $rabbitmq_server == *nodedown* ]]; then
     echo "$ts RABBITMQ-SERVER stopped"
  else
     echo "$ts RABBITMQ-SERVER running"
  fi
  
  # get vision-web-ui status
  web_ui=$(/sbin/service vision\-web\-ui status)
  #echo $web_ui > /tmp/web_ui_status
  if [[ $web_ui == *running* ]]; then
     echo "$ts VISION-WEB-UI running"
  else
     echo "$ts VISION-WEB-UI stopped"
  fi 

  # get nodetool status
  nodetool_status=$(/opt/cassandra/bin/nodetool status)
  #echo $nodetool_status > /tmp/nodetool_status
  echo "$ts NODETOOL-STATUS $nodetool_status"
  ;;
"msp")
  # do only msp stuff

  # get vision-assetmanager status
  vision_assetmanager_status=$(/sbin/service vision\-assetmanager status | cut -d ' ' -f 6 | sed 's/\.//')
  if [ "$vision_assetmanager_status" == "running" ]; then
     echo "$ts VISION-ASSETMANAGER $vision_assetmanager_status"
  else
     echo "$ts VISION-ASSETMANAGER stopped"
  fi

  # get vision-contentshare status
  vision_contentshare_status=$(/sbin/service vision\-contentshare status | cut -d ' ' -f 6 | sed 's/\.//')
  if [ "$vision_contentshare_status" == "running" ]; then
     echo "$ts VISION-CONTENTSHARE $vision_contentshare_status"
  else
     echo "$ts VISION-CONTENTSHARE stopped"
  fi

  # get vision-contentsource status
  vision_contentsource_status=$(/sbin/service vision\-contentsource status | cut -d ' ' -f 6 | sed 's/\.//')
  if [ "$vision_contentsource_status" == "running" ]; then
     echo "$ts VISION-CONTENTSOURCE $vision_contentsource_status"
  else
     echo "$ts VISION-CONTENTSOURCE stopped"
  fi

  # get vision-downloader status
  vision_downloader_status=$(/sbin/service vision\-downloader status | cut -d ' ' -f 6 | sed 's/\.//')
  if [ "$vision_downloader_status" == "running" ]; then
     echo "$ts VISION-DOWNLOADER $vision_downloader_status"
  else
     echo "$ts VISION-DOWNLOADER stopped"
  fi

  # get puppet status
  puppet_status=$(/sbin/service puppet status | cut -d ' ' -f 6 | sed 's/\.//')
  if [ "$puppet_status" == "running" ]; then
     echo "$ts PUPPET $puppet_status"
  else
     echo "$ts PUPPET stopped"
  fi
  ;;
esac

