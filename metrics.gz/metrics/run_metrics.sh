#!/usr/bin/env bash
##########################################################################
### this runs the metrics collection script and concatenates it to a file
/root/metrics/get_metrics.sh >> /tmp/$(hostname)_metrics 2>&1
