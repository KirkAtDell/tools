#!/usr/bin/env bash
####################################################################
### Script to gather metrics concerning the computer's resources
### ./get_metrics.sh

# make a timestamp
ts=$(date -u +"%Y%m%d%H%M%S")
# get list of vision rpms
visionrpms_trunc=$(rpm -qa | sort | grep vision | tr '\n' ' '| cut -c -80)
echo "$ts NEW_ROW $(hostname) $visionrpms_trunc"

# get list of users on system
users=$(who | sed -r -e "s/[\t\ ]+/ /g" | sed ':a;N;$!ba;s/\n/,/g')
echo "$ts USERS $users"

# get list of vision rpms
visionrpms=$(rpm -qa | sort | grep vision | tr '\n' ' ')
echo "$ts VISION-RPMS $visionrpms"

# run top once and stick in temp file
top -n 1 -b > top_shot

# get the header of the temp top file
head -n 5 top_shot | sed -r -e "s/[\t\ ]+/ /g" > top_header

# parse the uptime from top_header
uptime=$(cat top_header | grep load | cut -d ' ' -f 5- | cut -d ' ' -f -3 | sed s/\,$//)
echo "$ts UPTIME $uptime"

# parse the load from the top_header
load=$(cat top_header | grep load | cut -d ' ' -f 12-14)
echo "$ts LOAD $load"

# parse the tasks from the top_header
tasks=$(cat top_header | grep -i tasks | cut -d ' ' -f 2-)
echo "$ts TASKS $tasks"

# parse the memory from the top_header
memory=$(cat top_header | grep -i mem | cut -d ' ' -f 2-)
echo "$ts MEMORY $memory"

# parse the swap from the top_header
swap=$(cat top_header | grep -i swap | cut -d ' ' -f 2-)
echo "$ts SWAP $swap"

# get the number of open files
openfiles=$(/usr/sbin/lsof | wc -l)
echo "$ts LSOF $openfiles"

# get the number of allocated file handles, number of allocated but not used, and the maximum
handles=$(/sbin/sysctl fs.file-nr | cut -d ' ' -f 3- | sed -r -e "s/[\t\ ]+/ /g")
echo "$ts FS.FILE-NR $handles"

# get iostats
iostat=$(/usr/bin/iostat | grep sd | sed -r -e "s/[\t\ ]+/ /g")
echo "$ts IOSTAT $iostat"

# get eht0 received packets
rxpacket=$(/sbin/ifconfig eth0 | grep packets | grep RX | sed -r -e "s/[\t\ ]+/ /g" | sed 's/ /,/g' | sed 's/,RX,//'| sed 's/:/ /g' | sed 's/,/, /g')
echo "$ts ETH0-RX $rxpacket"

# get eht0 transmitted packets
txpacket=$(/sbin/ifconfig eth0 | grep packets | grep TX | sed -r -e "s/[\t\ ]+/ /g" | sed 's/ /,/g' | sed 's/,TX,//'| sed 's/:/ /g' | sed 's/,/, /g')
echo "$ts ETH0-TX $txpacket"

# get count of errors in messages log
messageerrors=$(cat /var/log/messages | grep -i error | wc -l)
echo "$ts MESSAGES-ERROR $messageerrors"

# get count of warnings in messages log
messagewarnings=$(cat /var/log/messages | grep -i warn | wc -l)
echo "$ts MESSAGES-WARN $messagewarnings"

############ slib/MSM specific stuff #################
msm_has_multivbmgmt=$(ls -1 /opt/vce | grep -i multivbmgmt)
if [ "$msm_has_multivbmgmt" = "" ]; then
  # do sLib only stuff

  #check vce services, one-by-one
  vce_fm_master=$(service vce-fm-master status | cut -d ' ' -f 2- | sed 's/ /_/g' | sed 's/_(pid=[0-9]*_)//')
  echo "$ts VCE-FM-MASTER $vce_fm_master"
  vce_fm_adapter=$(service vce-fm-adapter status | cut -d ' ' -f 2- | sed 's/ /_/g' | sed 's/_(pid=[0-9]*_)//')
  echo "$ts VCE-FM-ADAPTER $vce_fm_adapter"
  vce_fm_agent=$(service vce-fm-agent status | cut -d ' ' -f 2- | sed 's/ /_/g' | sed 's/_(pid=[0-9]*_)//')
  echo "$ts VCE-FM-AGENT $vce_fm_agent"
  vce_fm_net_snmpd=$(service vce-fm-net-snmpd status | cut -d ' ' -f 4- | sed 's/ /_/g')
  echo "$ts VCE-FM-NET-SNMPD $vce_fm_net_snmpd"
  vce_fm_naaagent=$(service vce-fm-naaagent status | cut -d ' ' -f 2- | sed 's/ /_/g' | sed 's/_(pid=[0-9]*_)//')
  echo "$ts VCE-FM-NAAAGENT $vce_fm_naaagent"
  #run configuration collector

else
  # do msm only stuff

  # get df  information on VCE data space
  vcedata=$(df | egrep "\/opt\/vce\/data")
  echo "$ts VCE-DATA $vcedata"

  # get count of errors in CollectionManager.log
  collectionerrors=$(cat /opt/vce/multivbmgmt/logs/CollectionManager.log | grep -i error | wc -l)
  echo "$ts COLLECTION-ERROR $collectionerrors"

  # get count of warnings in CollectionManager.log
  collectionwarnings=$(cat /opt/vce/multivbmgmt/logs/CollectionManager.log | grep -i warn | wc -l)
  echo "$ts COLLECTION-WARN $collectionwarnings"

  # get tomcat status
  tomcat=$(service tomcat status | cut -d ' ' -f 6 | sed 's/\.//')
  if [ "$tomcat" == "running" ]; then
     echo "$ts TOMCAT $tomcat"
  else
     echo "$ts TOMCAT stopped"
  fi
  
  # get httpd status
  httpd=$(service httpd status | cut -d ' ' -f 6 | sed 's/\.\.\.//')
  if [ "$httpd" == "running" ]; then
     echo "$ts HTTPD $httpd"
  else
     echo "$ts HTTPD stopped"
  fi
  
  # get rsyslog status
  rsyslog=$(service rsyslog status | cut -d ' ' -f 6 | sed 's/\.\.\.//')
  if [ "$rsyslog" == "running" ]; then
     echo "$ts RSYSLOG $rsyslog"
  else
     echo "$ts RSYSLOG stopped"
  fi
  
  # get elasticsearch status
  elasticsearch=$(service elasticsearch status | cut -d ' ' -f 6 | sed 's/\.\.\.//')
  if [ "$elasticsearch" == "running" ]; then
     echo "$ts ELASTICSEARCH $elasticsearch"
  else
     echo "$ts ELASTICSEARCH stopped"
  fi
  
  # get multivbmgmt status
  multivbmgmt=$(service multivbmgmt status  | cut -d ' ' -f 6  | sed 's/\.\.\.//')
  if [ "$multivbmgmt" == "running" ]; then
     echo "$ts MULTIVBMGMT $multivbmgmt"
  else
     echo "$ts MULTIVBMGMT stopped"
  fi
  
  # get vision-shell status
  vision_shell=$(service vision\-shell status | cut -d ' ' -f 5)
  if [ "$vision_shell" == "running" ]; then
     echo "$ts VISION-SHELL $vision_shell"
  else
     echo "$ts VISION-SHELL stopped"
  fi
  
  # get vision-credential-manager status
  vision_credential_manager=$(service vision\-credential\-manager status | cut -d ' ' -f 6 | sed 's/\.//')
  if [ "$vision_credential_manager" == "running" ]; then
     echo "$ts VISION-CREDENTIAL-MANAGER $vision_credential_manager"
  else
     echo "$ts VISION-CREDENTIAL-MANAGER stopped"
  fi
  
  # get vision-mvb-compliance status
  vision_mvb_compliance=$(service vision\-mvb\-compliance status | cut -d ' ' -f 6 | sed 's/\.//')
  if [ "$vision_mvb_compliance" == "running" ]; then
     echo "$ts VISION-MVB-COMPLIANCE $vision_mvb_compliance"
  else
     echo "$ts VISION-MVB-COMPLIANCE stopped"
  fi
  
  # get rabbitmq-server status
  rabbitmq_server=$(service rabbitmq-server status)
  if [[ $rabbitmq_server == *nodedown* ]]; then
     echo "$ts RABBITMQ-SERVER stopped"
  else
     echo "$ts RABBITMQ-SERVER running"
  fi
  
  # get nodetool status
  nodetool_status=$(/opt/cassandra/bin/nodetool status)
  #echo $nodetool_status > /tmp/nodetool_status
  echo "$ts NODETOOL-STATUS $nodetool_status"

fi
