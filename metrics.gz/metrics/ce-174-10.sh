#!/usr/bin/env bash
HOSTNAME="${COLLECTD_HOSTNAME:-`hostname -f`}"
INTERVAL="${COLLECTD_INTERVAL:-60}"

#echo "HOSTNAME is $HOSTNAME and INTERVAL is $INTERVAL"
while sleep "$INTERVAL"; do
   # query HTTPD
   active=$(/bin/systemctl status  httpd.service | grep Active)
   if [[ ${active} != *"running"* ]]; then
      state=0
   else 
      state=1
   fi
   echo "PUTVAL \"$HOSTNAME/ce/httpd-status\" interval=$INTERVAL N:$state"
   # query NTPD
   active=$(/bin/systemctl status  ntpd.service | grep Active)
   if [[ ${active} != *"running"* ]]; then
      state=0
   else 
      state=1
   fi
   echo "PUTVAL \"$HOSTNAME/ce/ntpd-status\" interval=$INTERVAL N:$state"
done
