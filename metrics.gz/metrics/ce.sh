#!/usr/bin/env bash
HOSTNAME="${COLLECTD_HOSTNAME:-`hostname -f`}"
INTERVAL="${COLLECTD_INTERVAL:-60}"

#echo "HOSTNAME is $HOSTNAME and INTERVAL is $INTERVAL"
while sleep "$INTERVAL"; do
   # query HTTPD
   active=$(/sbin/service httpd status)
   if [[ ${active} != *"running"* ]]; then
      state=0
   else 
      state=1
   fi
   echo "PUTVAL \"$HOSTNAME/ce/httpd-status\" interval=$INTERVAL N:$state"
   # query NTPD
   active=$(/sbin/service ntpd status)
   if [[ ${active} != *"running"* ]]; then
      state=0
   else 
      state=1
   fi
   echo "PUTVAL \"$HOSTNAME/ce/ntpd-status\" interval=$INTERVAL N:$state"
   # query tomcat
   active=$(/sbin/service tomcat status | cut -d ' ' -f 6 | sed 's/\.//')
   if [[ ${active} != *"running"* ]]; then
      state=0
   else 
      state=1
   fi
   echo "PUTVAL \"$HOSTNAME/ce/tomcat-status\" interval=$INTERVAL N:$state"
done
