#!/usr/bin/env bash
#####################################################
### install our cronjob, only once
###
crontable=$(crontab -l)
if echo $crontable | grep -q "Cron to collect metrics"
  then echo "metrics collection is already scheduled"
  else crontab -l > nowcron; cat nowcron our_cronjob > newcron; crontab newcron; crontab -l
fi
