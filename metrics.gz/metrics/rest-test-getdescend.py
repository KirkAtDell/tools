#!/usr/bin/python

import pytest
import requests
#import vcr

#count of objects returned from vcesystem descendants call - 30min
#*/30 * * * * /root/rest-test-getdescend.py >> /tmp/countofobjects


host = 'vision174-189.mpe.lab.vce.com'

def get_cookie():
    # Setup MSM config, TODO: get from command line
   # host = 'fm17.v3fx1.vtg.vce.com'
    username = 'admin'
    password = 'D@ngerous1'

    # Build up base URLS
    base_url = 'https://' + host + ':443'
    tickets_url = base_url + '/cas/v1/tickets'
    cvm_auth_url = base_url + '/cvm/auth'

    # Ticket Granting Ticket
    tgt = requests.request('POST', url=tickets_url, data={'username': username, 'password': password}, verify=False)
    st_url = tgt.headers['Location']

    # Service Ticket
    st = requests.request('POST', url=st_url, data='service=' + cvm_auth_url, verify=False)

    # Get Cookie Jar to chain to data requests
    cj = requests.request('POST', url=cvm_auth_url + '?ticket=' + st.text, verify=False, allow_redirects=False)

    return cj.cookies


from requests.packages.urllib3.exceptions import InsecurePlatformWarning, InsecureRequestWarning,SNIMissingWarning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
requests.packages.urllib3.disable_warnings(InsecurePlatformWarning)
requests.packages.urllib3.disable_warnings(SNIMissingWarning)


def test_auth_requests(get_cookie):
    """
    Make a request to MSM with an authentication cookie injected
    """
    #host = 'fm17.v3fx1.vtg.vce.com'
    vblocks_url = 'https://' + host + '/cvm/mvmgmt/queries?q=find descendants of vcesystem'

    data = requests.request('GET', url=vblocks_url, verify=False, cookies=get_cookie)
    assert data.status_code == requests.codes.ok
    print data.json()['summary']['hits'],
    print data.json()['summary']['queryRespTime']
    assert data.json()['summary']['hits'] > 0


if __name__ == '__main__':
    mycookie = get_cookie()
    test_auth_requests(mycookie)


