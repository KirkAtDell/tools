#!/usr/bin/env bash
### create a cronjob to collect metrics
### install our cronjob, only once
###
/usr/bin/pip install cassandra-driver
/usr/bin/pip install pytest
/usr/bin/pip install requests
crontable=$(crontab -l)
if echo $crontable | grep -q "Cron to collect metrics"
  then echo "collection of metrics is already scheduled"
  else crontab -l > nowcron; cat nowcron our_cronjob > newcron; crontab newcron; crontab -l
fi
