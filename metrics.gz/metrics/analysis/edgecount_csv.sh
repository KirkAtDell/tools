#!/usr/bin/env bash
##############################################################
### Example that processes Regi's edgecount file and buids a CSV file
### of the edges data. Output to STDOUT
###
### edgecount lines:
###
### 201609221450 EDGES 228
### 201609221455 EDGES 228
### 201609221500 EDGES 228
###
### TEST USAGE: ./edgecount_cvs.sh edgecount > edgecount.csv
###
### USAGE:      ./edgecount_cvs.sh edgecount > edgecount.csv
#
###########           1         2         3         4
########### 01234567890123456789012345678901234567890   <--- ordinal position for snipping timestamp components
########### .            .     .      values            <--- the raw data values from metrics log line
########### 201609221450 EDGES 228                      <--- the raw data values from metrics log line
#  for cut  1            2     3        <--- for cut
#
echo "timestamp,edges"
while IFS='' read -r line || [[ -n "$line" ]]; do
  #echo "Text read from file: $line"
  # extract the components of the timestamp
  timestamp=$(echo $line |  awk '{ print $1 }')
  edges=$(echo $line |  awk '{ print $3 }')
  echo $timestamp","$edges
done < "$1"
