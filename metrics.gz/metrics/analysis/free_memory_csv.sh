#!/usr/bin/env bash
##############################################################
### Example that processes metrics file and buids a CSV file
### of the free memory data. Output to STDOUT
###
### TEST USAGE: head -n 40 fm42.v3fx1.vtg.vce.com_metrics > /tmp/test; ./free_memory_csv.sh /tmp/test
###
### USAGE:      ./free_memory_csv.sh /tmp/test fm42.v3fx1.vtg.vce.com_metrics > free_memory.csv
#
#           1         2         3         4
# 01234567890123456789012345678901234567890   <--- ordinal position for snipping timestamp components
# .   . . . . .         values                <--- the raw data values from metrics log line
# 20150929233501 MEMORY 12198084k total, 11950944k used, 247140k free, 354896k buffers
#  for cut              1         2      3         4     5       6     7       8 <--- for cut
#
while IFS='' read -r line || [[ -n "$line" ]]; do
    #echo "Text read from file: $line"
    if [[ $line == *"MEMORY"* ]]; then # process the MEMORY data: 
       # extract the components of the timestamp
        year=${line:0:4}
        month=${line:4:2}
        day=${line:6:2}
        hour=${line:8:2}
        min=${line:10:2}
        sec=${line:12:2}
        # get the free memory value: get the MEMORY data, cut out the free value and convert the 'k' to '000'
        values=${line:22}
        free=$( echo "$values" | cut -d ' ' -f5)
        new_value=$(sed 's/k/000/' <<< "$free")
        # output the new line as: Year/Month/Day Hour:Minute:Second,converted free memory value ... CSV format
        echo "$year/$month/$day $hour:$min:$sec,$new_value" 
    fi
done < "$1"
