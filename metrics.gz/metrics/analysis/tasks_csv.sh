#!/usr/bin/env bash
##############################################################
### Example that processes metrics file and buids a CSV file
### of the open files data. Output to STDOUT
###
### TEST USAGE: head -n 40 fm62.v3fx1.vtg.vce.com_metrics > /tmp/test; ./open_files_csv.sh /tmp/test
###
### USAGE:      ./open_files_csv.sh /tmp/test fm62.v3fx1.vtg.vce.com_metrics > open_files.csv
#
#           1         2         3         4
# 01234567890123456789012345678901234567890   <--- ordinal position for snipping timestamp components
# .   . . . . .       values                <--- the raw data values from metrics log line
# 20160503152501 TASKS 196 total,
#  for cut             1   2      3         4     5       6     7       8 <--- for cut
#
while IFS='' read -r line || [[ -n "$line" ]]; do
    #echo "Text read from file: $line"
    if [[ $line == *"TASKS"* ]]; then # process the LSOF data: 
       # extract the components of the timestamp
        year=${line:0:4}
        month=${line:4:2}
        day=${line:6:2}
        hour=${line:8:2}
        min=${line:10:2}
        sec=${line:12:2}
        # get the open files value: get the TASKS data, cut out the one value
        value=${line:21}
        tasks=$( echo "$value" | cut -d ' ' -f1)
        # output the new line as: Year/Month/Day Hour:Minute:Second,open files value ... CSV format
        echo "$year/$month/$day $hour:$min:$sec,$tasks" 
    fi
done < "$1"
