#!/usr/bin/env bash
##############################################################
### Example that processes metrics file and buids a CSV file
### of the allocated file handles data. Output to STDOUT
###
### TEST USAGE: head -n 40 fm42.v3fx1.vtg.vce.com_metrics > /tmp/test; ./allocated_handles_csv.sh /tmp/test
###
### USAGE:      ./allocated_handles_csv.sh /tmp/test fm42.v3fx1.vtg.vce.com_metrics > allocated_handles.csv
#
#           1         2         3         4
# 01234567890123456789012345678901234567890   <--- ordinal position for snipping timestamp components
# .   . . . . .             values            <--- the raw data values from metrics log line
# 20150929233501 FS.FILE-NR 5024 0 1209762
#  for cut                  1    2 3          <--- for cut
#
while IFS='' read -r line || [[ -n "$line" ]]; do
    #echo "Text read from file: $line"
    if [[ $line == *"FS.FILE-NR"* ]]; then # process the FS.FILE-NR data: 
       # extract the components of the timestamp
        year=${line:0:4}
        month=${line:4:2}
        day=${line:6:2}
        hour=${line:8:2}
        min=${line:10:2}
        sec=${line:12:2}
        # get the allocated file handles values: get the FS.FILE-NR data, cut out the allocated value
        values=${line:26}
        allocated=$( echo "$values" | cut -d ' ' -f1)
        # output the new line as: Year/Month/Day Hour:Minute:Second,converted allocated value ... CSV format
        echo "$year/$month/$day $hour:$min:$sec,$allocated" 
    fi
done < "$1"
