#!/usr/bin/env bash
##############################################################
### Example that processes my_cpuload file and buids a CSV file
### of the netstat cpuload data. Output to STDOUT
###
### TEST USAGE: ./cpuload_csv.sh my_cpuload
###
### USAGE:      ./cpuload_csv.sh my_cpuload > cpuload.csv
#
#TIMESTAMP 2016-08-24_1540 TIMESTAMP $
#L^@o^@a^@d^@P^@e^@r^@c^@e^@n^@t^@a^@g^@e^@ ^@ ^@^M$
#^@1^@ ^@ ^@ ^@ ^@ ^@ ^@ ^@ ^@ ^@ ^@ ^@ ^@ ^@ ^@ ^@^M$
#^@TIMESTAMP 2016-08-24_1545 TIMESTAMP $
#L^@o^@a^@d^@P^@e^@r^@c^@e^@n^@t^@a^@g^@e^@ ^@ ^@^M$
#^@1^@ ^@ ^@ ^@ ^@ ^@ ^@ ^@ ^@ ^@ ^@ ^@ ^@ ^@ ^@ ^@^M$
#
# process the control cahracters out of file
tr -d '\000-\011\013\014\015\016-\037' < $1 > /tmp/$1
kludge=0 # minutes
percent=0
echo "TIME,CPU Load %"
while IFS='' read -r line || [[ -n "$line" ]]; do
    #echo "Text read from file: [$line]"
    if [[ $line == *"TIMESTAMP"* ]]; then # process the TIMESTAMP data 
       if [ $percent -ne 0 ]; then
          echo "$timestamp,$percent"
          percent=0 # reset percentage
       fi
       # extract the timestamp
        ts=$(echo $line |  awk '{ print "\x27" $2 }')
        if [ "${ts: -1}" == "_" ]; then
           hr=$(( kludge/60 ))
           mi=$(( kludge%60 ))
           hr_pad=$(printf "%02d" "$hr")
           mi_pad=$(printf "%02d" "$mi")
           suffix=$hr_pad$mi_pad
           (( kludge += 5 ))
           timestamp=$(echo $ts$suffix)
        else
           kludge=0
           timestamp=$(echo $ts)
        fi
        #echo $timestamp $ts $suffix $kludge
    else
       if ! [[ $line =~ '^[0-9]+$' ]] ; then
          percent=$line
       fi
    fi
done < "/tmp/$1"
echo "$timestamp,$percent"
