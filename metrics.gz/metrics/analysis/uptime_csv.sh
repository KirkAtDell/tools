#!/usr/bin/env bash
##############################################################
### Example that processes metrics file and buids a CSV file
### of the free memory data. Output to STDOUT
###
### TEST USAGE: head -n 40 fm42.v3fx1.vtg.vce.com_metrics > /tmp/test; ./uptime_csv.sh /tmp/test
###
### USAGE:      ./uptime_csv.sh /tmp/test fm42.v3fx1.vtg.vce.com_metrics > uptime.csv
#
#           1         2         3         4
# 01234567890123456789012345678901234567890   <--- ordinal position for snipping timestamp components
# .   . . . . .         values                <--- the raw data values from metrics log line
# 20150929233501 UPTIME 42 min,  1            .... this is what we get on a system up less than an hour (1 is user)
# 20150929233501 UPTIME 1:00,  1              .... this is what we get on a system up between 1 hour and 1 day (1 is user)
# 20150929233501 UPTIME 78 days, 1            .... this is what we get in the first hour over a day boundary (1 is minute)
# 20150929233501 UPTIME 78 days, 1            .... this is possible, on exact day boundary (1 is user)
# 20150929233501 UPTIME 78 days, 5:49         .... this is what we get most of the time
#  for cut              1  2     3            <--- for cut
#                                                  ... uptime was obviously written by a cretin
#
while IFS='' read -r line || [[ -n "$line" ]]; do
    #echo "Text read from file: $line"
    if [[ $line == *"UPTIME"* ]]; then # process the UPTIME data: 
       # extract the components of the timestamp
        year=${line:0:4}
        month=${line:4:2}
        day=${line:6:2}
        hour=${line:8:2}
        min=${line:10:2}
        sec=${line:12:2}
        # get the uptime value: get the UPTIME data, and try to resolve the fourteen thousand diffrent formats
        days=0
        hours=0
        minutes=0
        mins=0
        values=${line:22}
        if [[ $values == *"day"* ]]; then
           days=$( echo $values | cut -d ' ' -f1 )
           hrmi=$( echo $values | cut -d ' ' -f3 )
           if [[ $hrmi == *":"* ]]; then
              hours=$( echo $hrmi | cut -d ':' -f1 )
              minutes=$( echo $hrmi | cut -d ':' -f2 )
           else
              minutes=$hrmi
           fi
        else
           hrmi=$( echo $values | cut -d ' ' -f1 )
           if [[ $hrmi == *":"* ]]; then
              hours=$( echo $hrmi | cut -d ':' -f1 )
              minutes=$( echo $hrmi | cut -d ':' -f2 )
           else
              minutes=$hrmi
           fi
        fi
        up_hours=$( echo "scale=2; ($minutes/60) + $hours + ($days*24)" | bc )
        # output the new line as: Year/Month/Day Hour:Minute:Second,converted uptime value ... CSV format
        echo "$year/$month/$day $hour:$min:$sec,$up_hours" 
    fi
done < "$1"
