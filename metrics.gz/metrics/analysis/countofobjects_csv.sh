#!/usr/bin/env bash
##############################################################
### Example that processes Regi's countofobjects file and buids a CSV file
### of the hits & response time data. Output to STDOUT
###
### countofobjects lines:
###
### 201609221450 OBJECTS 0 3
### 201609221455 OBJECTS 0 1
### 201609221500 OBJECTS 0 4
###
### TEST USAGE: ./countofobjects_cvs.sh countofobjects > countofobjects.csv
###
### USAGE:      ./countofobjects_cvs.sh countofobjects > countofobjects.csv
#
###########           1         2         3         4
########### 01234567890123456789012345678901234567890   <--- ordinal position for snipping timestamp components
########### .   . . . . .         values                <--- the raw data values from metrics log line
########### 7961 18947
########### 201609221450 OBJECTS 0 3
#  for cut  1            2       3 4        <--- for cut
#
echo "timestamp,objects,response time"
while IFS='' read -r line || [[ -n "$line" ]]; do
  #echo "Text read from file: $line"
  # extract the components of the timestamp
  timestamp=$(echo $line |  awk '{ print $1 }')
  objects=$(echo $line |  awk '{ print $3 }')
  response=$(echo $line |  awk '{ print $4 }')
  response_sec=$(echo "scale=2;${response}/1000" | bc)
  echo $timestamp","$objects","$response_sec 
done < "$1"
