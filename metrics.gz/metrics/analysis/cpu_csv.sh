#!/usr/bin/env bash
##############################################################
### Example that processes metrics file and buids a CSV file
### of the cpu utilization data. Output to STDOUT
###
### mpstat lines:
###
### 17:35:43     CPU    %usr   %nice    %sys %iowait    %irq   %soft  %steal  %guest   %idle
### 17:35:43     all    6.55    0.04    1.18    0.10    0.09    0.25    0.00    0.00   91.79
###
### TEST USAGE: head -n 40 fm42.v3fx1.vtg.vce.com_metrics > /tmp/test; ./cpu_csv.sh /tmp/test
###
### USAGE:      ./cpu_csv.sh /tmp/test fm42.v3fx1.vtg.vce.com_metrics > cpu.csv
#
#           1         2         3         4         5         6         7         8         9
# 0123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890   <--- ordinal position for snipping timestamp components
# .   . . . . .         values                <--- the raw data values from metrics log line
# 20160822172208 CPU 6.54    0.04    1.18    0.10    0.09    0.25    0.00    0.00   91.8
#  for cut           1       2       3       4       5       6       7       8      9     <--- for cut
#
echo "timestamp,usr,nice,sys,iowait,irq,soft,steal,guest,idle"
while IFS='' read -r line || [[ -n "$line" ]]; do
    #echo "Text read from file: $line"
    if [[ $line == *"CPU"* ]]; then # process the CPU data: 
       # extract the components of the timestamp
       echo $line |  awk '{ print "\x27" $1 "," $3  "," $4  "," $5  "," $6  "," $7  "," $8 "," $9  "," $10  "," $11 }'
    fi
done < "$1"
