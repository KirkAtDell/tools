#!/usr/bin/env bash
#################################################################
### look for service outages in the MSM logs
grep stopped *_metrics | grep -v TASKS > service_outages_$1
