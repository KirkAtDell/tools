#!/usr/bin/env bash
##############################################################
### Example that processes my_connections file and buids a CSV file
### of the netstat connections data. Output to STDOUT
###
### TEST USAGE: ./connections_csv.sh my_connections
###
### USAGE:      ./connections_csv.sh my_connections > connections.csv
#
#TIMESTAMP 2016-08-24_1540 TIMESTAMP
#  TCP    10.3.51.85:135         prtg-networkmgr:51757  ESTABLISHED
#  TCP    10.3.51.85:3389        fm61:51331             ESTABLISHED
#  TCP    10.3.51.85:50749       ad1:49158              TIME_WAIT
#  TCP    10.3.51.85:50757       vision-135:5999        SYN_SENT
#TIMESTAMP 2016-08-24_1545 TIMESTAMP
#  TCP    10.3.51.85:135         prtg-networkmgr:52539  ESTABLISHED
#  TCP    10.3.51.85:3389        fm61:51331             ESTABLISHED
#  TCP    10.3.51.85:50784       ad1:49158              TIME_WAIT
#  TCP    10.3.51.85:50800       ad1:49158              ESTABLISHED
#
kludge=0 # minutes
connections=0
echo "TIME,Count"
while IFS='' read -r line || [[ -n "$line" ]]; do
    #echo "Text read from file: $line"
    if [[ $line == *"TIMESTAMP"* ]]; then # process the TIMESTAMP data 
       if [ $connections -ne 0 ]; then
          echo "$timestamp,$connections"
          connections=0 # reset connection count
       fi
       # extract the timestamp
        ts=$(echo $line |  awk '{ print "\x27" $2 }')
        if [ "${ts: -1}" == "_" ]; then
           hr=$(( kludge/60 ))
           mi=$(( kludge%60 ))
           hr_pad=$(printf "%02d" "$hr")
           mi_pad=$(printf "%02d" "$mi")
           suffix=$hr_pad$mi_pad
           (( kludge += 5 ))
           timestamp=$(echo $ts$suffix)
        else
           kludge=0
           timestamp=$(echo $ts)
        fi
        #echo $timestamp $ts $suffix $kludge
    else
       (( connections += 1 )) 
    fi
done < "$1"
echo "$timestamp,$connections"
