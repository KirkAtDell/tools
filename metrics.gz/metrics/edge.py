#!/usr/bin/python

import pip


import cassandra
from cassandra.cluster import Cluster
from cassandra.auth import PlainTextAuthProvider

##count of tital edges every 30 min
#*/30 * * * * python /root/edge.py >> /tmp/edgecount

ap = PlainTextAuthProvider(username="msm_user", password="am2ron@p")
c = Cluster(protocol_version=2, auth_provider=ap)
s = c.connect(keyspace="titan")
result = s.execute("select count(*) from edgestore limit 2000000")
edges =  result[0]
print edges[0]



